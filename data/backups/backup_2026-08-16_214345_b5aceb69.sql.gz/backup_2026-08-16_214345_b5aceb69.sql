-- ========================================================
-- ZSEM Tech Platform Database Backup
-- Generated: 2026-08-16 19:43:46 UTC
-- Driver: mysql
-- ========================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;


-- --------------------------------------------------------
-- Table structure for table `abuse_reports`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `abuse_reports`;
CREATE TABLE `abuse_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reporter_user_id` int(11) DEFAULT NULL,
  `report_type` varchar(80) NOT NULL DEFAULT 'other',
  `content_url` varchar(500) DEFAULT NULL,
  `description` text NOT NULL,
  `reporter_email` varchar(160) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `status` enum('new','reviewing','resolved','rejected') NOT NULL DEFAULT 'new',
  `admin_note` text DEFAULT NULL,
  `handled_by` int(11) DEFAULT NULL,
  `handled_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `handled_by` (`handled_by`),
  KEY `idx_status_created` (`status`,`created_at`),
  KEY `idx_reporter_created` (`reporter_user_id`,`created_at`),
  KEY `idx_ip_created` (`ip_address`,`created_at`),
  CONSTRAINT `abuse_reports_ibfk_1` FOREIGN KEY (`handled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `active_user_sessions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `active_user_sessions`;
CREATE TABLE `active_user_sessions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `session_hash` char(64) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent_hash` char(64) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `last_seen` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_user_session` (`user_id`,`session_hash`),
  KEY `idx_user_last_seen` (`user_id`,`last_seen`),
  KEY `idx_last_seen` (`last_seen`),
  CONSTRAINT `active_user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `active_user_sessions` VALUES 
(53, 1, '00c3eb0f770e4fc36f0c53535caa5e784ca4ebfc5dea7f01eadb51ae8617ddb7', '::1', '8792e0aa5199c3c96d7a6827b7e92d1a4205a8650150f4c6b497a2baa42380e1', '2026-08-16 21:30:17', '2026-08-16 21:40:29');

-- --------------------------------------------------------
-- Table structure for table `admin_audit_log`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `admin_audit_log`;
CREATE TABLE `admin_audit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL,
  `action` varchar(80) NOT NULL,
  `target_type` varchar(80) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_admin_created` (`admin_id`,`created_at`),
  KEY `idx_action_created` (`action`,`created_at`),
  CONSTRAINT `admin_audit_log_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_audit_log` VALUES 
(1, 1, 'create_feature_page_block', 'feature_page_block', 1, 'courses: user,teacher', '::1', '2026-07-02 18:41:55'),
(2, 1, 'create_feature_page_block', 'feature_page_block', 2, 'courses: user,teacher', '::1', '2026-07-02 18:44:19');

-- --------------------------------------------------------
-- Table structure for table `admin_request_replies`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `admin_request_replies`;
CREATE TABLE `admin_request_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `reply_text` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `admin_id` (`admin_id`),
  KEY `idx_request_created` (`request_id`,`created_at`),
  CONSTRAINT `admin_request_replies_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `admin_requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `admin_request_replies_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `admin_requests`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `admin_requests`;
CREATE TABLE `admin_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'general',
  `subject` varchar(180) NOT NULL,
  `message` text NOT NULL,
  `status` enum('sent','read','replied','closed') NOT NULL DEFAULT 'sent',
  `admin_reply` text DEFAULT NULL,
  `replied_by` int(11) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `replied_by` (`replied_by`),
  KEY `idx_status_created` (`status`,`created_at`),
  KEY `idx_teacher_created` (`teacher_id`,`created_at`),
  CONSTRAINT `admin_requests_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `admin_requests_ibfk_2` FOREIGN KEY (`replied_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `all_in_duel_usage`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `all_in_duel_usage`;
CREATE TABLE `all_in_duel_usage` (
  `user_id` int(11) NOT NULL,
  `usage_date` date NOT NULL,
  `usage_count` int(11) NOT NULL DEFAULT 0,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`,`usage_date`),
  CONSTRAINT `all_in_duel_usage_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `app_settings`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `app_settings`;
CREATE TABLE `app_settings` (
  `setting_key` varchar(80) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `app_settings` VALUES 
('exam_ai_copy_guard_1', '0', '2026-06-24 17:12:32');

-- --------------------------------------------------------
-- Table structure for table `badges`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `badges`;
CREATE TABLE `badges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `icon` varchar(50) NOT NULL DEFAULT 'bi-award',
  `color` varchar(20) NOT NULL DEFAULT '#3b82f6',
  `criteria_type` varchar(50) NOT NULL,
  `criteria_value` int(11) DEFAULT 1,
  `rarity` enum('common','uncommon','rare','epic','legendary') DEFAULT 'common',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `badges` VALUES 
(1, 'first_perfect', 'Pierwsza setka', '100% poprawnych odpowiedzi na teście', 'bi-trophy-fill', '#f59e0b', 'perfect_score', 1, 'rare', '2026-06-22 08:35:12'),
(2, 'winning_streak', 'Seria zwycięstw', '5 testów z rzędu z wynikiem >80%', 'bi-fire', '#ef4444', 'win_streak', 5, 'epic', '2026-06-22 08:35:12'),
(3, 'bookworm', 'Bibliotekarz', 'Rozwiąż 500 pytań', 'bi-book-fill', '#8b5cf6', 'questions_answered', 500, 'uncommon', '2026-06-22 08:35:12'),
(4, 'speedster', 'Błyskawica', 'Test ukończony w <5 min z wynikiem >90%', 'bi-lightning-fill', '#eab308', 'speed_test', 1, 'epic', '2026-06-22 08:35:12'),
(5, 'sniper', 'Snajper', '10 testów z rzędu bez błędu', 'bi-crosshair', '#10b981', 'flawless_streak', 10, 'legendary', '2026-06-22 08:35:12'),
(6, 'inf02_master', 'Mistrz INF.02', 'Opanowanie ponad 80% wszystkich pytań', 'bi-mortarboard-fill', '#6366f1', 'mastery_percent', 80, 'legendary', '2026-06-22 08:35:12'),
(7, 'fair_player', 'Uczciwy gracz', '0 naruszeń w sprawdzianie nauczyciela', 'bi-shield-check', '#22c55e', 'zero_violations', 1, 'common', '2026-06-22 08:35:12'),
(8, 'first_test', 'Pierwszy krok', 'Ukończ swój pierwszy test', 'bi-rocket-takeoff-fill', '#3b82f6', 'tests_completed', 1, 'common', '2026-06-22 08:35:12'),
(9, 'test_veteran', 'Weteran', 'Ukończ 50 testów', 'bi-star-fill', '#f97316', 'tests_completed', 50, 'rare', '2026-06-22 08:35:12'),
(10, 'night_owl', 'Nocna sowa', 'Rozwiąż test po godzinie 22:00', 'bi-moon-stars-fill', '#6366f1', 'night_test', 1, 'uncommon', '2026-06-22 08:35:12'),
(11, 'early_bird', 'Ranny ptaszek', 'Rozwiąż test przed godziną 7:00', 'bi-sunrise-fill', '#f59e0b', 'early_test', 1, 'uncommon', '2026-06-22 08:35:12'),
(12, 'social_butterfly', 'Towarzyski', 'Dodaj 10 znajomych', 'bi-people-fill', '#ec4899', 'friends_count', 10, 'uncommon', '2026-06-22 08:35:12'),
(13, 'exam_survivor', 'Ocalały', 'Ukończ sprawdzian nauczyciela', 'bi-award-fill', '#14b8a6', 'exam_completed', 1, 'common', '2026-06-22 08:35:12'),
(14, 'top_scorer', 'Najlepszy wynik', 'Zajmij 1. miejsce w sprawdzianie nauczyciela', 'bi-1-circle-fill', '#f59e0b', 'exam_first_place', 1, 'epic', '2026-06-22 08:35:12'),
(15, 'marathon', 'Maratończyk', 'Rozwiąż łącznie 1000 pytań', 'bi-infinity', '#dc2626', 'questions_answered', 1000, 'rare', '2026-06-22 08:35:12');

-- --------------------------------------------------------
-- Table structure for table `banned_emails`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `banned_emails`;
CREATE TABLE `banned_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `reason` text DEFAULT NULL,
  `banned_at` datetime DEFAULT current_timestamp(),
  `banned_by` int(11) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`),
  KEY `banned_by` (`banned_by`),
  CONSTRAINT `banned_emails_ibfk_1` FOREIGN KEY (`banned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `banned_ips`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `banned_ips`;
CREATE TABLE `banned_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `reason` text DEFAULT NULL,
  `banned_at` datetime DEFAULT current_timestamp(),
  `banned_by` int(11) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  KEY `idx_ip` (`ip_address`),
  KEY `banned_by` (`banned_by`),
  CONSTRAINT `banned_ips_ibfk_1` FOREIGN KEY (`banned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `course_custom_labs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `course_custom_labs`;
CREATE TABLE `course_custom_labs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `tool_key` varchar(50) NOT NULL,
  `instructions` text NOT NULL,
  `topology_data` longtext DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `teacher_id` (`teacher_id`),
  CONSTRAINT `course_custom_labs_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `course_enrollments`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `course_enrollments`;
CREATE TABLE `course_enrollments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `enrolled_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_course_user` (`course_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `course_enrollments_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `course_enrollments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `course_items`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `course_items`;
CREATE TABLE `course_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` enum('text','video','quiz','lab','exam') NOT NULL,
  `content` longtext DEFAULT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  `quiz_passing_score` int(11) NOT NULL DEFAULT 70,
  `lab_source` enum('sandbox','custom') DEFAULT 'sandbox',
  `lab_tool_key` varchar(50) DEFAULT NULL,
  `lab_custom_id` int(11) DEFAULT NULL,
  `lab_instructions` text DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `lab_custom_id` (`lab_custom_id`),
  KEY `idx_module_sort` (`module_id`,`sort_order`),
  CONSTRAINT `course_items_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `course_modules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `course_items_ibfk_2` FOREIGN KEY (`lab_custom_id`) REFERENCES `course_custom_labs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `course_items` VALUES 
(5, 3, 'retert', 'text', '{\"version\":2,\"blocks\":[{\"type\":\"callout\",\"tone\":\"success\",\"title\":\"dg\",\"body\":\"dsf\"},{\"type\":\"text\",\"heading\":\"sf\",\"body\":\"sfsf\"},{\"type\":\"code\",\"language\":\"js\",\"code\":\"sdsfsfs\"}]}', NULL, 70, 'sandbox', NULL, NULL, NULL, 0, '2026-07-29 08:35:19'),
(6, 4, 'exam', 'exam', NULL, NULL, 70, 'sandbox', NULL, NULL, NULL, 0, '2026-07-29 08:38:35'),
(7, 3, 's', 'exam', NULL, NULL, 70, 'sandbox', NULL, NULL, NULL, 1, '2026-08-05 16:24:59');

-- --------------------------------------------------------
-- Table structure for table `course_modules`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `course_modules`;
CREATE TABLE `course_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_course_sort` (`course_id`,`sort_order`),
  CONSTRAINT `course_modules_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `course_modules` VALUES 
(3, 4, 'kappuj', NULL, 0, '2026-07-29 08:35:12'),
(4, 4, 'koniec', NULL, 1, '2026-07-29 08:38:24'),
(5, 5, 'w', 'w', 0, '2026-08-05 16:24:38');

-- --------------------------------------------------------
-- Table structure for table `course_quiz_questions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `course_quiz_questions`;
CREATE TABLE `course_quiz_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `question_text` text NOT NULL,
  `option_a` varchar(255) NOT NULL,
  `option_b` varchar(255) NOT NULL,
  `option_c` varchar(255) DEFAULT NULL,
  `option_d` varchar(255) DEFAULT NULL,
  `correct_answer` enum('A','B','C','D') NOT NULL,
  `explanation` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `course_quiz_questions_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `course_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `course_quiz_questions` VALUES 
(1, 6, 'k', 'q', 'w', 'e', 'r', 'A', NULL),
(2, 7, 'dw', 'd', 'd', NULL, NULL, 'A', NULL);

-- --------------------------------------------------------
-- Table structure for table `course_shares`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `course_shares`;
CREATE TABLE `course_shares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `shared_with_user_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_course_share` (`course_id`,`shared_with_user_id`),
  KEY `idx_course_share_user` (`shared_with_user_id`,`course_id`),
  CONSTRAINT `course_shares_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `course_shares_ibfk_2` FOREIGN KEY (`shared_with_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `courses`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `courses`;
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `difficulty` enum('beginner','intermediate','advanced') DEFAULT NULL,
  `estimated_hours` int(10) unsigned DEFAULT NULL,
  `status` enum('active','hidden','private') NOT NULL DEFAULT 'hidden',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `sequential_learning` tinyint(1) NOT NULL DEFAULT 0,
  `has_certificate` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `is_external` tinyint(1) NOT NULL DEFAULT 0,
  `external_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `courses` VALUES 
(4, 'wfa', 'sfda', NULL, NULL, NULL, 'beginner', 10, 'active', NULL, NULL, '2026-07-29 08:23:22', '2026-07-29 09:37:03', 0, 1, NULL, 0, NULL),
(5, 'Kurs test', 'dew3dewd', NULL, NULL, NULL, NULL, NULL, 'private', NULL, NULL, '2026-08-01 14:17:29', '2026-08-05 16:24:31', 0, 0, 1, 0, NULL);

-- --------------------------------------------------------
-- Table structure for table `duel_answers`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `duel_answers`;
CREATE TABLE `duel_answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `duel_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `user_answer` char(1) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT 0,
  `time_spent` int(11) NOT NULL DEFAULT 0,
  `answered_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_duel_user_question` (`duel_id`,`user_id`,`question_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `duel_answers_ibfk_1` FOREIGN KEY (`duel_id`) REFERENCES `duels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `duel_answers_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `duels`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `duels`;
CREATE TABLE `duels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenger_id` int(11) NOT NULL,
  `opponent_id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `question_count` int(11) NOT NULL DEFAULT 10,
  `question_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`question_ids`)),
  `mode` varchar(30) NOT NULL DEFAULT 'classic',
  `preset` varchar(40) NOT NULL DEFAULT 'classic',
  `stake_xp` int(11) NOT NULL DEFAULT 0,
  `underdog_bonus` decimal(4,2) NOT NULL DEFAULT 1.00,
  `time_per_question_seconds` int(11) DEFAULT NULL,
  `total_time_seconds` int(11) DEFAULT NULL,
  `require_answer_confirmation` tinyint(1) NOT NULL DEFAULT 0,
  `allow_early_finish` tinyint(1) NOT NULL DEFAULT 1,
  `status` enum('pending','accepted','declined','finished','expired') NOT NULL DEFAULT 'pending',
  `challenger_score_percent` decimal(5,2) DEFAULT 0.00,
  `opponent_score_percent` decimal(5,2) DEFAULT 0.00,
  `challenger_time_spent` int(11) DEFAULT NULL,
  `opponent_time_spent` int(11) DEFAULT NULL,
  `challenger_finished_at` datetime DEFAULT NULL,
  `opponent_finished_at` datetime DEFAULT NULL,
  `challenger_started_at` datetime DEFAULT NULL,
  `opponent_started_at` datetime DEFAULT NULL,
  `challenger_hidden_at` datetime DEFAULT NULL,
  `opponent_hidden_at` datetime DEFAULT NULL,
  `winner_id` int(11) DEFAULT NULL,
  `revenge_parent_id` int(11) DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `winner_id` (`winner_id`),
  KEY `idx_opponent_status` (`opponent_id`,`status`),
  KEY `idx_challenger_status` (`challenger_id`,`status`),
  CONSTRAINT `duels_ibfk_1` FOREIGN KEY (`challenger_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `duels_ibfk_2` FOREIGN KEY (`opponent_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `duels_ibfk_3` FOREIGN KEY (`winner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `exam_answers`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `exam_answers`;
CREATE TABLE `exam_answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `participant_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `question_order` int(11) DEFAULT 0,
  `user_answer` char(1) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `correct_answer` char(1) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `is_correct` tinyint(1) DEFAULT 0,
  `time_spent` int(11) DEFAULT 0,
  `answered_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_participant_question` (`participant_id`,`question_id`),
  KEY `idx_session_participant` (`session_id`,`participant_id`),
  KEY `idx_participant_order` (`participant_id`,`question_order`),
  CONSTRAINT `exam_answers_ibfk_1` FOREIGN KEY (`participant_id`) REFERENCES `exam_participants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_answers_ibfk_2` FOREIGN KEY (`session_id`) REFERENCES `exam_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `exam_participants`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `exam_participants`;
CREATE TABLE `exam_participants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `class` varchar(20) NOT NULL,
  `status` enum('in_lobby','taking_exam','finished','removed','disconnected') DEFAULT 'in_lobby',
  `current_question` int(11) DEFAULT 0,
  `correct_answers` int(11) DEFAULT 0,
  `total_answered` int(11) DEFAULT 0,
  `score_percent` decimal(5,2) DEFAULT 0.00,
  `time_spent` int(11) DEFAULT 0,
  `violation_count` int(11) DEFAULT 0,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `joined_at` datetime DEFAULT current_timestamp(),
  `last_activity` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_status` (`status`),
  KEY `idx_session_user_status` (`session_id`,`user_id`,`status`),
  KEY `idx_session_status_joined` (`session_id`,`status`,`joined_at`),
  CONSTRAINT `exam_participants_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `exam_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_participants_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `exam_session_questions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `exam_session_questions`;
CREATE TABLE `exam_session_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `question_order` int(11) DEFAULT 0,
  `correct_answer_override` char(1) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `override_reason` varchar(255) DEFAULT NULL,
  `override_by` int(11) DEFAULT NULL,
  `override_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_session_question` (`session_id`,`question_id`),
  KEY `idx_session_order` (`session_id`,`question_order`),
  CONSTRAINT `exam_session_questions_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `exam_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `exam_session_questions` VALUES 
(1, 1, 137171881, 1, NULL, NULL, NULL, NULL),
(2, 1, 59556653, 2, NULL, NULL, NULL, NULL),
(3, 1, 87344673, 3, NULL, NULL, NULL, NULL),
(4, 1, 57060738, 4, NULL, NULL, NULL, NULL),
(5, 1, 33051077, 5, NULL, NULL, NULL, NULL),
(6, 1, 112352454, 6, NULL, NULL, NULL, NULL),
(7, 1, 252284619, 7, NULL, NULL, NULL, NULL),
(8, 1, 79965233, 8, NULL, NULL, NULL, NULL),
(9, 1, 16329542, 9, NULL, NULL, NULL, NULL),
(10, 1, 152877426, 10, NULL, NULL, NULL, NULL),
(11, 1, 96109329, 11, NULL, NULL, NULL, NULL),
(12, 1, 242274983, 12, NULL, NULL, NULL, NULL),
(13, 1, 164349509, 13, NULL, NULL, NULL, NULL),
(14, 1, 39280585, 14, NULL, NULL, NULL, NULL),
(15, 1, 229557778, 15, NULL, NULL, NULL, NULL),
(16, 1, 154118539, 16, NULL, NULL, NULL, NULL),
(17, 1, 145425431, 17, NULL, NULL, NULL, NULL),
(18, 1, 250878042, 18, NULL, NULL, NULL, NULL),
(19, 1, 36297365, 19, NULL, NULL, NULL, NULL),
(20, 1, 232867052, 20, NULL, NULL, NULL, NULL),
(21, 1, 116922468, 21, NULL, NULL, NULL, NULL),
(22, 1, 268147178, 22, NULL, NULL, NULL, NULL),
(23, 1, 150756123, 23, NULL, NULL, NULL, NULL),
(24, 1, 110008323, 24, NULL, NULL, NULL, NULL),
(25, 1, 141019278, 25, NULL, NULL, NULL, NULL),
(26, 1, 187893309, 26, NULL, NULL, NULL, NULL),
(27, 1, 85820890, 27, NULL, NULL, NULL, NULL),
(28, 1, 71938554, 28, NULL, NULL, NULL, NULL),
(29, 1, 156450802, 29, NULL, NULL, NULL, NULL),
(30, 1, 226360603, 30, NULL, NULL, NULL, NULL),
(31, 1, 74161299, 31, NULL, NULL, NULL, NULL),
(32, 1, 210623368, 32, NULL, NULL, NULL, NULL),
(33, 1, 28623045, 33, NULL, NULL, NULL, NULL),
(34, 1, 204164173, 34, NULL, NULL, NULL, NULL),
(35, 1, 19514046, 35, NULL, NULL, NULL, NULL),
(36, 1, 67139742, 36, NULL, NULL, NULL, NULL),
(37, 1, 81770276, 37, NULL, NULL, NULL, NULL),
(38, 1, 139784762, 38, NULL, NULL, NULL, NULL),
(39, 1, 55340684, 39, NULL, NULL, NULL, NULL),
(40, 1, 6824713, 40, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------
-- Table structure for table `exam_sessions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `exam_sessions`;
CREATE TABLE `exam_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `access_code` varchar(20) NOT NULL,
  `status` enum('lobby','in_progress','paused','finished','expired') DEFAULT 'lobby',
  `started_at` datetime DEFAULT NULL,
  `paused_at` datetime DEFAULT NULL,
  `paused_seconds` int(11) NOT NULL DEFAULT 0,
  `finished_at` datetime DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `access_code` (`access_code`),
  KEY `exam_id` (`exam_id`),
  KEY `idx_code` (`access_code`),
  KEY `idx_status` (`status`),
  CONSTRAINT `exam_sessions_ibfk_1` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `exam_sessions` VALUES 
(1, 1, '7R775C', 'finished', NULL, NULL, 0, '2026-06-24 17:12:43', '2026-06-24 18:12:34', '2026-06-24 17:12:34');

-- --------------------------------------------------------
-- Table structure for table `exam_violations`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `exam_violations`;
CREATE TABLE `exam_violations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `participant_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `violation_type` enum('tab_switch','window_blur','fullscreen_exit','copy_paste','other') NOT NULL,
  `question_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `participant_id` (`participant_id`),
  KEY `session_id` (`session_id`),
  CONSTRAINT `exam_violations_ibfk_1` FOREIGN KEY (`participant_id`) REFERENCES `exam_participants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_violations_ibfk_2` FOREIGN KEY (`session_id`) REFERENCES `exam_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `exam_warnings`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `exam_warnings`;
CREATE TABLE `exam_warnings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `participant_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `message` varchar(500) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  KEY `idx_participant_read` (`participant_id`,`is_read`),
  CONSTRAINT `exam_warnings_ibfk_1` FOREIGN KEY (`participant_id`) REFERENCES `exam_participants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_warnings_ibfk_2` FOREIGN KEY (`session_id`) REFERENCES `exam_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `exams`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `exams`;
CREATE TABLE `exams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `question_count` int(11) DEFAULT 40,
  `selected_questions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`selected_questions`)),
  `categories` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`categories`)),
  `difficulty_level` enum('easy','medium','hard','mixed') DEFAULT 'mixed',
  `shuffle_questions` tinyint(1) DEFAULT 1,
  `shuffle_answers` tinyint(1) DEFAULT 0,
  `max_participants` int(11) DEFAULT 36,
  `time_per_question` int(11) DEFAULT NULL,
  `total_time` int(11) DEFAULT NULL,
  `exam_mode` tinyint(1) DEFAULT 1,
  `auto_finish_on_time` tinyint(1) DEFAULT 1,
  `allow_rejoin` tinyint(1) DEFAULT 0,
  `anti_cheat_enabled` tinyint(1) DEFAULT 0,
  `block_tab_switch` tinyint(1) DEFAULT 0,
  `require_fullscreen` tinyint(1) DEFAULT 0,
  `lobby_enabled` tinyint(1) DEFAULT 1,
  `show_results_to_student` tinyint(1) DEFAULT 0,
  `show_predicted_grade` tinyint(1) DEFAULT 0,
  `show_correct_answers` tinyint(1) DEFAULT 0,
  `randomize_per_student` tinyint(1) DEFAULT 0,
  `lock_after_finish` tinyint(1) DEFAULT 1,
  `pass_threshold` tinyint(3) unsigned DEFAULT 50,
  `max_attempts` tinyint(3) unsigned DEFAULT 1,
  `navigation_mode` varchar(30) NOT NULL DEFAULT 'free',
  `allow_answer_changes` tinyint(1) NOT NULL DEFAULT 1,
  `warning_limit` tinyint(3) unsigned DEFAULT NULL,
  `warning_action` varchar(30) NOT NULL DEFAULT 'notify',
  `late_join_cutoff_minutes` tinyint(3) unsigned DEFAULT NULL,
  `results_available_at` datetime DEFAULT NULL,
  `print_include_answer_key` tinyint(1) NOT NULL DEFAULT 0,
  `available_from` datetime DEFAULT NULL,
  `available_until` datetime DEFAULT NULL,
  `grade_thresholds` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`grade_thresholds`)),
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_teacher` (`teacher_id`),
  CONSTRAINT `exams_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `exams` VALUES 
(1, 1, 'qwqw', '', 40, NULL, NULL, 'mixed', 1, 0, 36, NULL, NULL, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 50, 1, 'free', 1, NULL, 'notify', NULL, NULL, 0, NULL, NULL, NULL, '2026-06-24 17:12:32', '2026-06-24 17:12:32');

-- --------------------------------------------------------
-- Table structure for table `feature_page_blocks`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `feature_page_blocks`;
CREATE TABLE `feature_page_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_key` varchar(80) NOT NULL,
  `title` varchar(160) NOT NULL,
  `body` text NOT NULL,
  `target_roles` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `disabled_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ended_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_category_active` (`category_key`,`is_active`),
  KEY `idx_active_disabled` (`is_active`,`disabled_at`),
  CONSTRAINT `feature_page_blocks_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `feature_page_blocks` VALUES 
(1, 'courses', 'W trakcie Tworzenia !', 'kappi', '[\"user\",\"teacher\"]', 0, 1, '2026-07-02 18:41:55', '2026-07-02 18:44:19', '2026-07-02 18:44:19'),
(2, 'courses', 'W trakcie Tworzenia !', 'kappi', '[\"user\",\"teacher\"]', 1, 1, '2026-07-02 18:44:19', '2026-07-02 18:44:19', NULL);

-- --------------------------------------------------------
-- Table structure for table `friends`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `friends`;
CREATE TABLE `friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  `status` enum('pending','accepted') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_friendship` (`user_id`,`friend_id`),
  KEY `idx_friend_lookup` (`user_id`,`friend_id`,`status`),
  KEY `idx_friend_reverse` (`friend_id`,`user_id`,`status`),
  CONSTRAINT `friends_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `friends_ibfk_2` FOREIGN KEY (`friend_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `lessons`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `lessons`;
CREATE TABLE `lessons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(160) NOT NULL,
  `body` text NOT NULL,
  `pdf_path` varchar(255) DEFAULT NULL,
  `pdf_filename` varchar(255) DEFAULT NULL,
  `pdf_download_allowed` tinyint(1) NOT NULL DEFAULT 0,
  `qualification` varchar(20) NOT NULL DEFAULT 'general',
  `lesson_type` enum('lesson','homework') NOT NULL DEFAULT 'lesson',
  `status` enum('published','archived') NOT NULL DEFAULT 'published',
  `due_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status_created` (`status`,`created_at`),
  KEY `idx_teacher_status` (`teacher_id`,`status`),
  KEY `idx_qualification_status` (`qualification`,`status`),
  CONSTRAINT `lessons_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `login_attempts`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `attempt_time` datetime DEFAULT current_timestamp(),
  `success` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_username_time` (`username`,`attempt_time`),
  KEY `idx_time` (`attempt_time`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `login_attempts` VALUES 
(2, '192.168.1.135', 'test', '2026-07-10 21:31:14', 0),
(3, '192.168.1.135', 'test', '2026-07-10 21:31:28', 0),
(4, '192.168.1.135', 'test', '2026-07-10 21:36:59', 0),
(5, '192.168.1.135', 'test', '2026-07-10 22:02:32', 0);

-- --------------------------------------------------------
-- Table structure for table `luki_spins`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `luki_spins`;
CREATE TABLE `luki_spins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `spin_date` date NOT NULL,
  `archetype` varchar(40) NOT NULL,
  `label` varchar(120) NOT NULL,
  `xp_delta` int(11) NOT NULL DEFAULT 0,
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_date` (`user_id`,`spin_date`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `luki_spins_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `notifications`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `dedupe_key` varchar(160) DEFAULT NULL,
  `action_url` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_unread` (`user_id`,`is_read`),
  KEY `idx_user_unread_created` (`user_id`,`is_read`,`created_at`),
  KEY `idx_user_dedupe` (`user_id`,`dedupe_key`,`created_at`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `notifications` VALUES 
(2, 1, 'mfa_optional_declined', 'Czy włączyć 2 etapowe uwierzytelnianie?', 1, 'mfa_optional_prompt:1:dyrektor', NULL, '2026-06-22 10:46:58'),
(9, 2, 'daily_missions_refresh', 'Twoje codzienne misje zostały odświeżone! Sprawdź nowe wyzwania.', 0, '51728c97cfa7dc46ed09b7fb06cad99179e547a2a8ce3287f435b3e670f26f79', 'user/goals.php', '2026-07-03 19:12:52'),
(10, 3, 'daily_missions_refresh', 'Twoje codzienne misje zostały odświeżone! Sprawdź nowe wyzwania.', 0, 'e9684ac3925fe5e49b373e0c407e9c31afc7031b9862e5a470a8b9e6735bbd1e', 'user/goals.php', '2026-07-10 21:34:32'),
(16, 1, 'daily_missions_refresh', 'Twoje codzienne misje zostały odświeżone! Sprawdź nowe wyzwania.', 0, '4add9f01960d7d2802ed17042411b8537eafa905d7e69046b2fa34886f773c66', 'user/goals.php', '2026-08-16 21:30:17'),
(17, 1, 'weekly_missions_refresh', 'Twoje tygodniowe misje zostały odświeżone! Sprawdź nowe wyzwania.', 0, 'da1a992626872d1265272cb3994d859503f7aef65bf24b158ee76dd8155f700b', 'user/goals.php', '2026-08-16 21:31:00');

-- --------------------------------------------------------
-- Table structure for table `password_resets`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `idx_user_created` (`user_id`,`created_at`),
  KEY `idx_expires_used` (`expires_at`,`used_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `profile_comments`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `profile_comments`;
CREATE TABLE `profile_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `comment_text` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `idx_profile_created` (`profile_user_id`,`created_at`),
  CONSTRAINT `profile_comments_ibfk_1` FOREIGN KEY (`profile_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `profile_comments_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `questions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL DEFAULT '',
  `question_text` text NOT NULL,
  `option_a` varchar(500) NOT NULL DEFAULT '',
  `option_b` varchar(500) NOT NULL DEFAULT '',
  `option_c` varchar(500) NOT NULL DEFAULT '',
  `option_d` varchar(500) NOT NULL DEFAULT '',
  `correct_answer` char(1) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `explanation` text DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `rank_definitions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `rank_definitions`;
CREATE TABLE `rank_definitions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `min_xp` int(11) NOT NULL,
  `icon` varchar(80) NOT NULL DEFAULT 'bi-shield-fill',
  `color` varchar(20) NOT NULL DEFAULT '#3b82f6',
  `description` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_rank_name` (`name`),
  KEY `idx_min_xp` (`min_xp`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `rank_definitions` VALUES 
(1, 'Bronze V', 0, 'bi-shield', '#64748b', 'Startowa ranga użytkownika.', 1, '2026-06-22 08:35:11'),
(2, 'Bronze IV', 250, 'bi-shield', '#64748b', 'Początek drogi w IT.', 1, '2026-06-22 08:35:11'),
(3, 'Bronze III', 500, 'bi-shield', '#64748b', 'Pierwsze kroki za Tobą.', 1, '2026-06-22 08:35:11'),
(4, 'Bronze II', 800, 'bi-shield', '#64748b', 'Rozgrzewka przed wyzwaniami.', 1, '2026-06-22 08:35:11'),
(5, 'Bronze I', 1100, 'bi-shield', '#64748b', 'Granica wejścia do wyższej ligi.', 1, '2026-06-22 08:35:11'),
(6, 'Silver V', 1500, 'bi-shield-fill', '#94a3b8', 'Pierwszy próg regularnej nauki.', 1, '2026-06-22 08:35:11'),
(7, 'Silver IV', 2000, 'bi-shield-fill', '#94a3b8', 'Stabilny postęp w nauce.', 1, '2026-06-22 08:35:11'),
(8, 'Silver III', 2600, 'bi-shield-fill', '#94a3b8', 'Coraz lepsza znajomość materiału.', 1, '2026-06-22 08:35:11'),
(9, 'Silver II', 3300, 'bi-shield-fill', '#94a3b8', 'Dobry poziom systematyczności.', 1, '2026-06-22 08:35:11'),
(10, 'Silver I', 4100, 'bi-shield-fill', '#94a3b8', 'Granica wejścia do złotej ligi.', 1, '2026-06-22 08:35:11'),
(11, 'Gold V', 5000, 'bi-award-fill', '#f59e0b', 'Zaawansowany poziom aktywności.', 1, '2026-06-22 08:35:11'),
(12, 'Gold IV', 6000, 'bi-award-fill', '#f59e0b', 'Wysoka regularność pracy.', 1, '2026-06-22 08:35:11'),
(13, 'Gold III', 7100, 'bi-award-fill', '#f59e0b', 'Złoty standard wiedzy.', 1, '2026-06-22 08:35:11'),
(14, 'Gold II', 8300, 'bi-award-fill', '#f59e0b', 'Wybitna systematyczność.', 1, '2026-06-22 08:35:11'),
(15, 'Gold I', 9600, 'bi-award-fill', '#f59e0b', 'Prestiżowy poziom Gold.', 1, '2026-06-22 08:35:11'),
(16, 'Platinum V', 11000, 'bi-gem', '#0ea5e9', 'Platynowy progres.', 1, '2026-06-22 08:35:11'),
(17, 'Platinum IV', 12500, 'bi-gem', '#0ea5e9', 'Wysoka biegłość w testach.', 1, '2026-06-22 08:35:11'),
(18, 'Platinum III', 14100, 'bi-gem', '#0ea5e9', 'Dążenie do perfekcji.', 1, '2026-06-22 08:35:11'),
(19, 'Platinum II', 15800, 'bi-gem', '#0ea5e9', 'Mistrzowski poziom Platyny.', 1, '2026-06-22 08:35:11'),
(20, 'Platinum I', 17600, 'bi-gem', '#0ea5e9', 'Ostatni krok przed Diamentem.', 1, '2026-06-22 08:35:11'),
(21, 'Diamond V', 19500, 'bi-diamond-fill', '#8b5cf6', 'Ekspercki poziom Diamond.', 1, '2026-06-22 08:35:11'),
(22, 'Diamond IV', 21500, 'bi-diamond-fill', '#8b5cf6', 'Wyjątkowa wiedza techniczna.', 1, '2026-06-22 08:35:11'),
(23, 'Diamond III', 23600, 'bi-diamond-fill', '#8b5cf6', 'Diamentowa precyzja.', 1, '2026-06-22 08:35:11'),
(24, 'Diamond II', 25800, 'bi-diamond-fill', '#8b5cf6', 'Weteran platformy.', 1, '2026-06-22 08:35:11'),
(25, 'Diamond I', 28100, 'bi-diamond-fill', '#8b5cf6', 'Najwyższy poziom Diamentu.', 1, '2026-06-22 08:35:11'),
(26, 'Master V', 30500, 'bi-stars', '#ec4899', 'Mistrzowski poziom Master.', 1, '2026-06-22 08:35:11'),
(27, 'Master IV', 33000, 'bi-stars', '#ec4899', 'Incredible skills.', 1, '2026-06-22 08:35:11'),
(28, 'Master III', 35600, 'bi-stars', '#ec4899', 'Master of the platform.', 1, '2026-06-22 08:35:11'),
(29, 'Master II', 38300, 'bi-stars', '#ec4899', 'Legendary status.', 1, '2026-06-22 08:35:11'),
(30, 'Master I', 41100, 'bi-stars', '#ec4899', 'Absolute mastery.', 1, '2026-06-22 08:35:11'),
(31, 'Grandmaster V', 44000, 'bi-trophy-fill', '#ef4444', 'Grandmaster of ZSEM Tech.', 1, '2026-06-22 08:35:11'),
(32, 'Grandmaster IV', 47000, 'bi-trophy-fill', '#ef4444', 'Elite knowledge.', 1, '2026-06-22 08:35:11'),
(33, 'Grandmaster III', 50100, 'bi-trophy-fill', '#ef4444', 'World-class expertise.', 1, '2026-06-22 08:35:11'),
(34, 'Grandmaster II', 53300, 'bi-trophy-fill', '#ef4444', 'Peak performance.', 1, '2026-06-22 08:35:11'),
(35, 'Grandmaster I', 56600, 'bi-trophy-fill', '#ef4444', 'Ultimate Grandmaster.', 1, '2026-06-22 08:35:11'),
(36, 'Wujek luki', 75000, 'bi-crown-fill', '#facc15', 'Legenda ZSEM Tech.', 1, '2026-06-22 08:35:11');

-- --------------------------------------------------------
-- Table structure for table `ranking_event_templates`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `ranking_event_templates`;
CREATE TABLE `ranking_event_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(120) NOT NULL,
  `name` varchar(160) NOT NULL,
  `description` varchar(255) NOT NULL,
  `multiplier` decimal(4,2) NOT NULL DEFAULT 1.10,
  `duration_days` int(11) NOT NULL DEFAULT 7,
  `season` varchar(80) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `ranking_events`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `ranking_events`;
CREATE TABLE `ranking_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) DEFAULT NULL,
  `name` varchar(160) NOT NULL,
  `description` varchar(255) NOT NULL,
  `multiplier` decimal(4,2) NOT NULL DEFAULT 1.10,
  `starts_at` datetime NOT NULL,
  `ends_at` datetime NOT NULL,
  `status` enum('scheduled','active','finished','cancelled') NOT NULL DEFAULT 'active',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status_dates` (`status`,`starts_at`,`ends_at`),
  KEY `idx_template` (`template_id`),
  CONSTRAINT `ranking_events_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `ranking_event_templates` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `rate_limit_events`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `rate_limit_events`;
CREATE TABLE `rate_limit_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bucket` varchar(80) NOT NULL,
  `identity_hash` char(64) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_bucket_identity_created` (`bucket`,`identity_hash`,`created_at`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `sandbox_element_blocks`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `sandbox_element_blocks`;
CREATE TABLE `sandbox_element_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `element_key` varchar(120) NOT NULL,
  `title` varchar(160) NOT NULL,
  `body` text NOT NULL,
  `target_roles` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `disabled_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ended_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_element_active` (`element_key`,`is_active`),
  KEY `idx_active_disabled` (`is_active`,`disabled_at`),
  CONSTRAINT `sandbox_element_blocks_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `test_answers`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `test_answers`;
CREATE TABLE `test_answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `result_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `user_answer` char(1) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `correct_answer` char(1) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `is_correct` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_result_id` (`result_id`),
  KEY `idx_question_correct` (`question_id`,`is_correct`),
  KEY `idx_result_question` (`result_id`,`question_id`),
  CONSTRAINT `test_answers_ibfk_1` FOREIGN KEY (`result_id`) REFERENCES `test_results` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=681 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `test_answers` VALUES 
(1, 1, 121614018, 'A', 'A', 1),
(2, 1, 16659992, '', 'A', 0),
(3, 1, 224074393, 'B', 'A', 0),
(4, 1, 144830888, '', 'A', 0),
(5, 1, 190744512, '', 'B', 0),
(6, 1, 28623045, '', 'C', 0),
(7, 1, 159696729, '', 'B', 0),
(8, 1, 186553041, '', 'C', 0),
(9, 1, 76012242, '', 'A', 0),
(10, 1, 15620681, '', 'A', 0),
(11, 1, 75611461, '', 'C', 0),
(12, 1, 227533198, '', 'A', 0),
(13, 1, 3269464, '', 'A', 0),
(14, 1, 74399906, '', 'A', 0),
(15, 1, 79459014, '', 'D', 0),
(16, 1, 226444663, '', 'A', 0),
(17, 1, 159191939, '', 'A', 0),
(18, 1, 10321174, '', 'A', 0),
(19, 1, 195639816, '', 'C', 0),
(20, 1, 227635688, '', 'A', 0),
(21, 1, 109351679, '', 'D', 0),
(22, 1, 209865792, '', 'C', 0),
(23, 1, 75787615, '', 'C', 0),
(24, 1, 95992171, '', 'C', 0),
(25, 1, 258915997, '', 'B', 0),
(26, 1, 146533625, '', 'B', 0),
(27, 1, 132857831, '', 'A', 0),
(28, 1, 54262822, '', 'D', 0),
(29, 1, 193481312, '', 'A', 0),
(30, 1, 190291624, '', 'B', 0),
(31, 1, 137116772, '', 'A', 0),
(32, 1, 212247868, '', 'A', 0),
(33, 1, 231901011, '', 'A', 0),
(34, 1, 164192833, '', 'A', 0),
(35, 1, 163457401, '', 'D', 0),
(36, 1, 65272320, '', 'C', 0),
(37, 1, 201633850, '', 'B', 0),
(38, 1, 45497889, '', 'B', 0),
(39, 1, 41311393, '', 'A', 0),
(40, 1, 182682655, '', 'A', 0),
(41, 2, 220340263, '', 'D', 0),
(42, 2, 201131357, '', 'A', 0),
(43, 2, 25835671, '', 'C', 0),
(44, 2, 155841660, '', 'D', 0),
(45, 2, 175422661, '', 'A', 0),
(46, 2, 201349054, '', 'D', 0),
(47, 2, 81649492, '', 'D', 0),
(48, 2, 260430527, '', 'A', 0),
(49, 2, 7809067, '', 'D', 0),
(50, 2, 120259563, '', 'C', 0),
(51, 2, 159196953, '', 'A', 0),
(52, 2, 246572628, '', 'B', 0),
(53, 2, 9100913, '', 'B', 0),
(54, 2, 19042117, '', 'C', 0),
(55, 2, 215180104, '', 'A', 0),
(56, 2, 238266102, '', 'B', 0),
(57, 2, 248433617, '', 'A', 0),
(58, 2, 147814572, '', 'D', 0),
(59, 2, 149468540, '', 'C', 0),
(60, 2, 73032412, '', 'A', 0),
(61, 2, 232358374, '', 'A', 0),
(62, 2, 129685948, '', 'A', 0),
(63, 2, 265504792, '', 'A', 0),
(64, 2, 211187731, '', 'D', 0),
(65, 2, 66276040, '', 'A', 0),
(66, 2, 130426704, '', 'D', 0),
(67, 2, 85411793, '', 'A', 0),
(68, 2, 258454574, '', 'B', 0),
(69, 2, 139957144, '', 'C', 0),
(70, 2, 103202119, '', 'A', 0),
(71, 2, 18883847, '', 'D', 0),
(72, 2, 156731447, '', 'A', 0),
(73, 2, 163055675, '', 'D', 0),
(74, 2, 147198600, '', 'A', 0),
(75, 2, 159041597, '', 'A', 0),
(76, 2, 106060768, '', 'A', 0),
(77, 2, 39043015, '', 'A', 0),
(78, 2, 140033450, '', 'D', 0),
(79, 2, 229066976, '', 'A', 0),
(80, 2, 226677739, '', 'D', 0),
(81, 3, 204933982, '', 'A', 0),
(82, 3, 9503891, '', 'A', 0),
(83, 3, 116922468, '', 'A', 0),
(84, 3, 208560883, '', 'B', 0),
(85, 3, 140033450, '', 'D', 0),
(86, 3, 76012242, '', 'A', 0),
(87, 3, 201434078, '', 'D', 0),
(88, 3, 195422326, '', 'B', 0),
(89, 3, 206974416, '', 'A', 0),
(90, 3, 169267294, '', 'D', 0),
(91, 3, 11925150, '', 'A', 0),
(92, 3, 196589113, '', 'A', 0),
(93, 3, 111125780, '', 'A', 0),
(94, 3, 253447828, '', 'A', 0),
(95, 3, 225030585, '', 'A', 0),
(96, 3, 97164642, '', 'A', 0),
(97, 3, 60257440, '', 'D', 0),
(98, 3, 114546175, '', 'B', 0),
(99, 3, 198377919, '', 'A', 0),
(100, 3, 110783927, '', 'B', 0),
(101, 3, 129635704, '', 'A', 0),
(102, 3, 175048306, '', 'A', 0),
(103, 3, 99960442, '', 'A', 0),
(104, 3, 81034250, '', 'A', 0),
(105, 3, 88733930, '', 'B', 0),
(106, 3, 44926156, '', 'D', 0),
(107, 3, 38150314, '', 'A', 0),
(108, 3, 25835671, '', 'C', 0),
(109, 3, 105310738, '', 'D', 0),
(110, 3, 172592063, '', 'A', 0),
(111, 3, 13837215, '', 'A', 0),
(112, 3, 189654882, '', 'D', 0),
(113, 3, 246747359, '', 'A', 0),
(114, 3, 208089238, '', 'C', 0),
(115, 3, 247178592, '', 'D', 0),
(116, 3, 222713074, '', 'A', 0),
(117, 3, 154118539, '', 'A', 0),
(118, 3, 121429931, '', 'C', 0),
(119, 3, 88933866, '', 'A', 0),
(120, 3, 658298, '', 'D', 0),
(121, 4, 244738730, '', 'A', 0),
(122, 4, 123227382, '', 'A', 0),
(123, 4, 66820590, '', 'B', 0),
(124, 4, 167177273, '', 'C', 0),
(125, 4, 234743094, '', 'A', 0),
(126, 4, 143963990, '', 'C', 0),
(127, 4, 236562118, '', 'B', 0),
(128, 4, 232874827, '', 'B', 0),
(129, 4, 133287139, '', 'A', 0),
(130, 4, 250864701, '', 'B', 0),
(131, 4, 181654946, '', 'C', 0),
(132, 4, 198464314, '', 'D', 0),
(133, 4, 170627566, '', 'B', 0),
(134, 4, 81126731, '', 'B', 0),
(135, 4, 153207065, '', 'A', 0),
(136, 4, 186785289, '', 'B', 0),
(137, 4, 8031481, '', 'C', 0),
(138, 4, 6283819, '', 'B', 0),
(139, 4, 92231865, '', 'B', 0),
(140, 4, 212706772, '', 'C', 0),
(141, 4, 205596856, '', 'C', 0),
(142, 4, 141763077, '', 'B', 0),
(143, 4, 40486317, '', 'B', 0),
(144, 4, 126948935, '', 'B', 0),
(145, 4, 40907065, '', 'C', 0),
(146, 4, 241896098, '', 'A', 0),
(147, 4, 64033237, '', 'C', 0),
(148, 4, 95282303, '', 'B', 0),
(149, 4, 162328040, '', 'C', 0),
(150, 4, 182378366, '', 'D', 0),
(151, 4, 123098666, '', 'C', 0),
(152, 4, 11956924, '', 'D', 0),
(153, 4, 137784546, '', 'B', 0),
(154, 4, 213814483, '', 'C', 0),
(155, 4, 44926156, '', 'D', 0),
(156, 4, 260379205, '', 'D', 0),
(157, 4, 126840505, '', 'B', 0),
(158, 4, 87344673, '', 'C', 0),
(159, 4, 260923762, '', 'D', 0),
(160, 4, 50812879, '', 'C', 0),
(161, 5, 48073044, 'A', 'C', 0),
(162, 5, 20318573, 'B', 'B', 1),
(163, 5, 248520616, '', 'C', 0),
(164, 5, 45497889, '', 'B', 0),
(165, 5, 199495457, '', 'B', 0),
(166, 5, 132835266, '', 'C', 0),
(167, 5, 79289126, '', 'C', 0),
(168, 5, 245746117, '', 'C', 0),
(169, 5, 263181361, '', 'B', 0),
(170, 5, 81649492, '', 'D', 0),
(171, 5, 7800507, '', 'D', 0),
(172, 5, 224514859, '', 'A', 0),
(173, 5, 157956850, '', 'C', 0),
(174, 5, 114241440, '', 'B', 0),
(175, 5, 15638134, '', 'C', 0),
(176, 5, 187291171, '', 'A', 0),
(177, 5, 266396649, '', 'D', 0),
(178, 5, 208089238, '', 'C', 0),
(179, 5, 150659093, '', 'B', 0),
(180, 5, 121661250, '', 'A', 0),
(181, 5, 168951305, '', 'B', 0),
(182, 5, 39687280, '', 'B', 0),
(183, 5, 17027893, '', 'D', 0),
(184, 5, 232874827, '', 'B', 0),
(185, 5, 198589789, '', 'D', 0),
(186, 5, 8381534, '', 'B', 0),
(187, 5, 128042176, '', 'C', 0),
(188, 5, 87344673, '', 'C', 0),
(189, 5, 120259563, '', 'C', 0),
(190, 5, 165842167, '', 'B', 0),
(191, 5, 214629773, '', 'D', 0),
(192, 5, 157146078, '', 'A', 0),
(193, 5, 236562118, '', 'B', 0),
(194, 5, 141763077, '', 'B', 0),
(195, 5, 54262822, '', 'D', 0),
(196, 5, 46715275, '', 'D', 0),
(197, 5, 131888020, '', 'D', 0),
(198, 5, 36337108, '', 'B', 0),
(199, 5, 40155627, '', 'A', 0),
(200, 5, 126840505, '', 'B', 0),
(201, 6, 103714899, 'A', 'B', 0),
(202, 6, 132835266, 'B', 'C', 0),
(203, 6, 155674836, '', 'C', 0),
(204, 6, 84206831, '', 'B', 0),
(205, 6, 261370252, '', 'D', 0),
(206, 6, 201633850, '', 'B', 0),
(207, 6, 17577413, '', 'A', 0),
(208, 6, 205059186, '', 'C', 0),
(209, 6, 209948135, '', 'B', 0),
(210, 6, 116388214, '', 'B', 0),
(211, 6, 139784762, '', 'D', 0),
(212, 6, 214629773, '', 'D', 0),
(213, 6, 58626002, '', 'A', 0),
(214, 6, 10252119, '', 'A', 0),
(215, 6, 215588463, '', 'C', 0),
(216, 6, 119990543, '', 'B', 0),
(217, 6, 137564605, '', 'C', 0),
(218, 6, 39976501, '', 'D', 0),
(219, 6, 115294401, '', 'C', 0),
(220, 6, 259890953, '', 'C', 0),
(221, 6, 9955183, '', 'B', 0),
(222, 6, 135581765, '', 'A', 0),
(223, 6, 172409304, '', 'D', 0),
(224, 6, 243354540, '', 'D', 0),
(225, 6, 157053385, '', 'C', 0),
(226, 6, 105086837, '', 'C', 0),
(227, 6, 57665212, '', 'C', 0),
(228, 6, 42836291, '', 'C', 0),
(229, 6, 130188972, '', 'B', 0),
(230, 6, 52188687, '', 'C', 0),
(231, 6, 37057205, '', 'C', 0),
(232, 6, 159196953, '', 'A', 0),
(233, 6, 54337529, '', 'D', 0),
(234, 6, 67139742, '', 'C', 0),
(235, 6, 141374969, '', 'A', 0),
(236, 6, 52876221, '', 'A', 0),
(237, 6, 123065485, '', 'C', 0),
(238, 6, 67727675, '', 'D', 0),
(239, 6, 192032374, '', 'A', 0),
(240, 6, 205064037, '', 'D', 0),
(241, 7, 54262822, 'A', 'D', 0),
(242, 7, 74157047, '', 'D', 0),
(243, 7, 209410630, '', 'B', 0),
(244, 7, 157053385, '', 'C', 0),
(245, 7, 86484612, '', 'C', 0),
(246, 7, 177727199, '', 'A', 0),
(247, 7, 150756123, '', 'C', 0),
(248, 7, 222713074, '', 'A', 0),
(249, 7, 6283819, '', 'B', 0),
(250, 7, 224674331, '', 'D', 0),
(251, 7, 247380633, '', 'C', 0),
(252, 7, 216766086, '', 'D', 0),
(253, 7, 41385609, '', 'B', 0),
(254, 7, 265221893, '', 'A', 0),
(255, 7, 19124894, '', 'C', 0),
(256, 7, 173106808, '', 'D', 0),
(257, 7, 5469537, '', 'C', 0),
(258, 7, 175537840, '', 'D', 0),
(259, 7, 57060738, '', 'D', 0),
(260, 7, 9300192, '', 'C', 0),
(261, 7, 94066630, '', 'C', 0),
(262, 7, 261905409, '', 'D', 0),
(263, 7, 153722871, '', 'B', 0),
(264, 7, 71265683, '', 'A', 0),
(265, 7, 113391107, '', 'C', 0),
(266, 7, 207825595, '', 'C', 0),
(267, 7, 224514859, '', 'A', 0),
(268, 7, 66663987, '', 'C', 0),
(269, 7, 76690138, '', 'B', 0),
(270, 7, 234700657, '', 'B', 0),
(271, 7, 171701497, '', 'D', 0),
(272, 7, 140068436, '', 'A', 0),
(273, 7, 70720326, '', 'A', 0),
(274, 7, 103714899, '', 'B', 0),
(275, 7, 64499546, '', 'A', 0),
(276, 7, 85411793, '', 'A', 0),
(277, 7, 87344673, '', 'C', 0),
(278, 7, 155474819, '', 'A', 0),
(279, 7, 230486904, '', 'D', 0),
(280, 7, 52876221, '', 'A', 0),
(281, 8, 28623045, 'A', 'C', 0),
(282, 8, 166844290, 'A', 'C', 0),
(283, 8, 6283819, '', 'B', 0),
(284, 8, 250864701, '', 'B', 0),
(285, 8, 196589113, '', 'A', 0),
(286, 8, 45065993, '', 'D', 0),
(287, 8, 147509666, '', 'C', 0),
(288, 8, 98268130, '', 'B', 0),
(289, 8, 182462229, '', 'D', 0),
(290, 8, 5469537, '', 'C', 0),
(291, 8, 49376798, '', 'B', 0),
(292, 8, 219700056, '', 'D', 0),
(293, 8, 122580394, '', 'D', 0),
(294, 8, 224674331, '', 'D', 0),
(295, 8, 103600741, '', 'C', 0),
(296, 8, 79558243, '', 'A', 0),
(297, 8, 182378366, '', 'D', 0),
(298, 8, 48369204, '', 'B', 0),
(299, 8, 43487301, '', 'A', 0),
(300, 8, 109714622, '', 'B', 0),
(301, 8, 96109329, '', 'B', 0),
(302, 8, 133287139, '', 'A', 0),
(303, 8, 206516540, '', 'B', 0),
(304, 8, 243042077, '', 'A', 0),
(305, 8, 103062385, '', 'D', 0),
(306, 8, 57199677, '', 'A', 0),
(307, 8, 262197913, '', 'D', 0),
(308, 8, 240590160, '', 'D', 0),
(309, 8, 137564605, '', 'C', 0),
(310, 8, 215870476, '', 'A', 0),
(311, 8, 195638464, '', 'D', 0),
(312, 8, 133737641, '', 'B', 0),
(313, 8, 69308884, '', 'B', 0),
(314, 8, 62494844, '', 'C', 0),
(315, 8, 47269396, '', 'B', 0),
(316, 8, 85817279, '', 'C', 0),
(317, 8, 180182960, '', 'C', 0),
(318, 8, 76690138, '', 'B', 0),
(319, 8, 187589459, '', 'A', 0),
(320, 8, 52188687, '', 'C', 0),
(321, 9, 123074861, '', 'A', 0),
(322, 9, 189280776, '', 'D', 0),
(323, 9, 232358374, '', 'A', 0),
(324, 9, 58064971, '', 'C', 0),
(325, 9, 102226, '', 'C', 0),
(326, 9, 20241002, '', 'D', 0),
(327, 9, 40155627, '', 'A', 0),
(328, 9, 60257440, '', 'D', 0),
(329, 9, 245409299, '', 'D', 0),
(330, 9, 226035713, '', 'C', 0),
(331, 9, 152295290, '', 'A', 0),
(332, 9, 161208048, '', 'C', 0),
(333, 9, 81768449, '', 'C', 0),
(334, 9, 130873895, '', 'D', 0),
(335, 9, 128882507, '', 'A', 0),
(336, 9, 258418776, '', 'B', 0),
(337, 9, 214320927, '', 'C', 0),
(338, 9, 22827349, '', 'A', 0),
(339, 9, 222888322, '', 'C', 0),
(340, 9, 93589087, '', 'C', 0),
(341, 9, 17746613, '', 'D', 0),
(342, 9, 238685234, '', 'D', 0),
(343, 9, 220340263, '', 'D', 0),
(344, 9, 230725751, '', 'B', 0),
(345, 9, 205596856, '', 'C', 0),
(346, 9, 240590160, '', 'D', 0),
(347, 9, 214596760, '', 'A', 0),
(348, 9, 241896098, '', 'A', 0),
(349, 9, 224188840, '', 'B', 0),
(350, 9, 183698553, '', 'B', 0),
(351, 9, 65440407, '', 'D', 0),
(352, 9, 134760171, '', 'A', 0),
(353, 9, 71798109, '', 'C', 0),
(354, 9, 79289126, '', 'C', 0),
(355, 9, 238266102, '', 'B', 0),
(356, 9, 62494844, '', 'C', 0),
(357, 9, 95787419, '', 'A', 0),
(358, 9, 57609706, '', 'C', 0),
(359, 9, 43164542, '', 'A', 0),
(360, 9, 235110902, '', 'C', 0),
(361, 10, 182091331, 'B', 'B', 1),
(362, 10, 258454574, 'B', 'B', 1),
(363, 10, 115273577, 'A', 'D', 0),
(364, 10, 63438007, 'D', 'A', 0),
(365, 10, 14869956, '', 'C', 0),
(366, 10, 183978095, '', 'B', 0),
(367, 10, 99444933, '', 'B', 0),
(368, 10, 152295290, '', 'A', 0),
(369, 10, 245409299, '', 'D', 0),
(370, 10, 7800507, '', 'D', 0),
(371, 10, 104278096, '', 'B', 0),
(372, 10, 143963990, '', 'C', 0),
(373, 10, 42836291, '', 'C', 0),
(374, 10, 168223061, '', 'A', 0),
(375, 10, 80565285, '', 'B', 0),
(376, 10, 243354540, '', 'D', 0),
(377, 10, 164349509, '', 'A', 0),
(378, 10, 11645474, '', 'C', 0),
(379, 10, 9410552, '', 'B', 0),
(380, 10, 96332547, '', 'D', 0),
(381, 10, 242274983, '', 'C', 0),
(382, 10, 195723864, '', 'D', 0),
(383, 10, 75611461, '', 'C', 0),
(384, 10, 233532403, '', 'C', 0),
(385, 10, 231609667, '', 'A', 0),
(386, 10, 154087448, '', 'C', 0),
(387, 10, 226035713, '', 'C', 0),
(388, 10, 76690138, '', 'B', 0),
(389, 10, 125540807, '', 'B', 0),
(390, 10, 72264815, '', 'C', 0),
(391, 10, 52480414, '', 'D', 0),
(392, 10, 85411793, '', 'A', 0),
(393, 10, 186785289, '', 'B', 0),
(394, 10, 67176726, '', 'B', 0),
(395, 10, 247505404, '', 'A', 0),
(396, 10, 208089238, '', 'C', 0),
(397, 10, 71099818, '', 'B', 0),
(398, 10, 110783927, '', 'B', 0),
(399, 10, 71798109, '', 'C', 0),
(400, 10, 200793036, '', 'A', 0),
(401, 11, 125454055, '', 'A', 0),
(402, 11, 45090049, '', 'A', 0),
(403, 11, 13218832, '', 'C', 0),
(404, 11, 175156886, '', 'D', 0),
(405, 11, 138702713, '', 'A', 0),
(406, 11, 170627566, '', 'B', 0),
(407, 11, 162959175, '', 'C', 0),
(408, 11, 161348888, '', 'D', 0),
(409, 11, 106220024, '', 'A', 0),
(410, 11, 135581765, '', 'A', 0),
(411, 11, 146204809, '', 'C', 0),
(412, 11, 226707443, '', 'D', 0),
(413, 11, 205617693, '', 'A', 0),
(414, 11, 180302223, '', 'D', 0),
(415, 11, 108915027, '', 'D', 0),
(416, 11, 259796743, '', 'C', 0),
(417, 11, 143163633, '', 'A', 0),
(418, 11, 223834489, '', 'A', 0),
(419, 11, 134083094, '', 'A', 0),
(420, 11, 87152388, '', 'D', 0),
(421, 11, 119990543, '', 'B', 0),
(422, 11, 36852812, '', 'D', 0),
(423, 11, 86355492, '', 'A', 0),
(424, 11, 230043116, '', 'D', 0),
(425, 11, 133245664, '', 'D', 0),
(426, 11, 64392765, '', 'C', 0),
(427, 11, 217010292, '', 'D', 0),
(428, 11, 131082880, '', 'D', 0),
(429, 11, 159199422, '', 'B', 0),
(430, 11, 242077547, '', 'A', 0),
(431, 11, 131883808, '', 'A', 0),
(432, 11, 210502529, '', 'A', 0),
(433, 11, 209427354, '', 'A', 0),
(434, 11, 74399906, '', 'A', 0),
(435, 11, 206317599, '', 'D', 0),
(436, 11, 118141889, '', 'C', 0),
(437, 11, 174131471, '', 'A', 0),
(438, 11, 23309907, '', 'B', 0),
(439, 11, 197318821, '', 'D', 0),
(440, 11, 251254153, '', 'B', 0),
(441, 12, 207777015, 'A', 'C', 0),
(442, 12, 260768436, '', 'A', 0),
(443, 12, 67727675, '', 'D', 0),
(444, 12, 10840035, '', 'B', 0),
(445, 12, 191310535, '', 'A', 0),
(446, 12, 127289750, '', 'A', 0),
(447, 12, 88733930, '', 'B', 0),
(448, 12, 62292117, '', 'D', 0),
(449, 12, 222888322, '', 'C', 0),
(450, 12, 133737641, '', 'B', 0),
(451, 12, 5469537, '', 'C', 0),
(452, 12, 12783590, '', 'B', 0),
(453, 12, 251941969, '', 'D', 0),
(454, 12, 123227382, '', 'A', 0),
(455, 12, 47523920, '', 'D', 0),
(456, 12, 102226, '', 'C', 0),
(457, 12, 135581765, '', 'A', 0),
(458, 12, 182125913, '', 'A', 0),
(459, 12, 176519339, '', 'A', 0),
(460, 12, 91183755, '', 'B', 0),
(461, 12, 10252119, '', 'A', 0),
(462, 12, 46715275, '', 'D', 0),
(463, 12, 197342623, '', 'C', 0),
(464, 12, 132760728, '', 'A', 0),
(465, 12, 71798109, '', 'C', 0),
(466, 12, 235826727, '', 'A', 0),
(467, 12, 202956827, '', 'B', 0),
(468, 12, 31213075, '', 'C', 0),
(469, 12, 167177273, '', 'C', 0),
(470, 12, 209905895, '', 'D', 0),
(471, 12, 194048291, '', 'A', 0),
(472, 12, 219039374, '', 'C', 0),
(473, 12, 121429931, '', 'C', 0),
(474, 12, 2151530, '', 'A', 0),
(475, 12, 128882507, '', 'A', 0),
(476, 12, 50494816, '', 'B', 0),
(477, 12, 50812879, '', 'C', 0),
(478, 12, 178744448, '', 'D', 0),
(479, 12, 153345232, '', 'B', 0),
(480, 12, 114519837, '', 'A', 0),
(481, 13, 79289126, 'B', 'C', 0),
(482, 13, 128042176, '', 'C', 0),
(483, 13, 72920274, '', 'C', 0),
(484, 13, 67077647, '', 'B', 0),
(485, 13, 197422236, '', 'D', 0),
(486, 13, 216766086, '', 'D', 0),
(487, 13, 54262822, '', 'D', 0),
(488, 13, 147814572, '', 'D', 0),
(489, 13, 128990640, '', 'B', 0),
(490, 13, 28303755, '', 'A', 0),
(491, 13, 256946375, '', 'B', 0),
(492, 13, 226035713, '', 'C', 0),
(493, 13, 201131357, '', 'A', 0),
(494, 13, 194087825, '', 'B', 0),
(495, 13, 173918341, '', 'C', 0),
(496, 13, 181654946, '', 'C', 0),
(497, 13, 192344417, '', 'B', 0),
(498, 13, 262850676, '', 'A', 0),
(499, 13, 215870476, '', 'A', 0),
(500, 13, 28858520, '', 'D', 0);
INSERT INTO `test_answers` VALUES 
(501, 13, 210235651, '', 'D', 0),
(502, 13, 171701497, '', 'D', 0),
(503, 13, 222824130, '', 'C', 0),
(504, 13, 94063670, '', 'C', 0),
(505, 13, 48073044, '', 'C', 0),
(506, 13, 229929589, '', 'C', 0),
(507, 13, 163786209, '', 'A', 0),
(508, 13, 183241509, '', 'C', 0),
(509, 13, 235826727, '', 'A', 0),
(510, 13, 253852814, '', 'B', 0),
(511, 13, 190250443, '', 'A', 0),
(512, 13, 72443878, '', 'D', 0),
(513, 13, 37839248, '', 'A', 0),
(514, 13, 232867052, '', 'A', 0),
(515, 13, 190744512, '', 'B', 0),
(516, 13, 224833355, '', 'D', 0),
(517, 13, 132094364, '', 'D', 0),
(518, 13, 141763077, '', 'B', 0),
(519, 13, 10840035, '', 'B', 0),
(520, 13, 180811144, '', 'C', 0),
(521, 14, 56246144, 'B', 'A', 0),
(522, 14, 4232276, 'A', 'C', 0),
(523, 14, 182125913, 'B', 'A', 0),
(524, 14, 184551505, '', 'A', 0),
(525, 14, 157146078, '', 'A', 0),
(526, 14, 125197167, '', 'D', 0),
(527, 14, 2108484, '', 'B', 0),
(528, 14, 210084331, '', 'B', 0),
(529, 14, 243354540, '', 'D', 0),
(530, 14, 89776158, '', 'C', 0),
(531, 14, 22847558, '', 'A', 0),
(532, 14, 234700657, '', 'B', 0),
(533, 14, 118141889, '', 'C', 0),
(534, 14, 197091707, '', 'D', 0),
(535, 14, 214569676, '', 'A', 0),
(536, 14, 6478424, '', 'C', 0),
(537, 14, 182844270, '', 'D', 0),
(538, 14, 224514859, '', 'A', 0),
(539, 14, 158717865, '', 'A', 0),
(540, 14, 184951606, '', 'C', 0),
(541, 14, 81126731, '', 'B', 0),
(542, 14, 218430831, '', 'A', 0),
(543, 14, 154087448, '', 'C', 0),
(544, 14, 245943867, '', 'C', 0),
(545, 14, 180811144, '', 'C', 0),
(546, 14, 105643015, '', 'C', 0),
(547, 14, 60216587, '', 'D', 0),
(548, 14, 43395030, '', 'C', 0),
(549, 14, 168845237, '', 'C', 0),
(550, 14, 74228574, '', 'D', 0),
(551, 14, 75787615, '', 'C', 0),
(552, 14, 219700056, '', 'D', 0),
(553, 14, 49376798, '', 'B', 0),
(554, 14, 41385609, '', 'B', 0),
(555, 14, 191826673, '', 'D', 0),
(556, 14, 190123948, '', 'D', 0),
(557, 14, 80149658, '', 'D', 0),
(558, 14, 70720326, '', 'A', 0),
(559, 14, 171701497, '', 'D', 0),
(560, 14, 14025800, '', 'B', 0),
(561, 15, 247586276, '', 'D', 0),
(562, 15, 214629773, '', 'D', 0),
(563, 15, 253852814, '', 'B', 0),
(564, 15, 2233382, '', 'B', 0),
(565, 15, 201633850, '', 'B', 0),
(566, 15, 170627566, '', 'B', 0),
(567, 15, 184323148, '', 'D', 0),
(568, 15, 76690138, '', 'B', 0),
(569, 15, 262784156, '', 'A', 0),
(570, 15, 190123948, '', 'D', 0),
(571, 15, 44714395, '', 'D', 0),
(572, 15, 178226114, '', 'D', 0),
(573, 15, 90948613, '', 'B', 0),
(574, 15, 40302949, '', 'D', 0),
(575, 15, 107764772, '', 'A', 0),
(576, 15, 123074861, '', 'A', 0),
(577, 15, 67176726, '', 'B', 0),
(578, 15, 44926156, '', 'D', 0),
(579, 15, 33309408, '', 'C', 0),
(580, 15, 132094364, '', 'D', 0),
(581, 15, 260768436, '', 'A', 0),
(582, 15, 54000132, '', 'A', 0),
(583, 15, 143963990, '', 'C', 0),
(584, 15, 230841725, '', 'D', 0),
(585, 15, 150659093, '', 'B', 0),
(586, 15, 134760171, '', 'A', 0),
(587, 15, 14869956, '', 'C', 0),
(588, 15, 4536817, '', 'C', 0),
(589, 15, 64499546, '', 'A', 0),
(590, 15, 88245519, '', 'B', 0),
(591, 15, 144553298, '', 'C', 0),
(592, 15, 171241423, '', 'D', 0),
(593, 15, 209865792, '', 'C', 0),
(594, 15, 241261020, '', 'D', 0),
(595, 15, 146533625, '', 'B', 0),
(596, 15, 199495457, '', 'B', 0),
(597, 15, 44931438, '', 'D', 0),
(598, 15, 153054506, '', 'D', 0),
(599, 15, 46629271, '', 'D', 0),
(600, 15, 190060678, '', 'D', 0),
(601, 16, 57609706, '', 'C', 0),
(602, 16, 79728674, '', 'C', 0),
(603, 16, 205596856, '', 'C', 0),
(604, 16, 180811144, '', 'C', 0),
(605, 16, 168845237, '', 'C', 0),
(606, 16, 96332547, '', 'D', 0),
(607, 16, 9520004, '', 'D', 0),
(608, 16, 52876221, '', 'A', 0),
(609, 16, 226035713, '', 'C', 0),
(610, 16, 161184072, '', 'C', 0),
(611, 16, 7800507, '', 'D', 0),
(612, 16, 20571522, '', 'B', 0),
(613, 16, 168765644, '', 'C', 0),
(614, 16, 152829877, '', 'A', 0),
(615, 16, 65272320, '', 'C', 0),
(616, 16, 250169411, '', 'C', 0),
(617, 16, 198464314, '', 'D', 0),
(618, 16, 165064583, '', 'D', 0),
(619, 16, 198589789, '', 'D', 0),
(620, 16, 165992428, '', 'D', 0),
(621, 16, 74228574, '', 'D', 0),
(622, 16, 189574774, '', 'C', 0),
(623, 16, 88705388, '', 'D', 0),
(624, 16, 101428993, '', 'C', 0),
(625, 16, 59556653, '', 'C', 0),
(626, 16, 259796743, '', 'C', 0),
(627, 16, 31911143, '', 'C', 0),
(628, 16, 267649740, '', 'C', 0),
(629, 16, 16105883, '', 'A', 0),
(630, 16, 36337108, '', 'B', 0),
(631, 16, 6478424, '', 'C', 0),
(632, 16, 197342623, '', 'C', 0),
(633, 16, 94806179, '', 'A', 0),
(634, 16, 244738730, '', 'A', 0),
(635, 16, 109857060, '', 'C', 0),
(636, 16, 96063309, '', 'D', 0),
(637, 16, 127289750, '', 'A', 0),
(638, 16, 88771616, '', 'D', 0),
(639, 16, 163786209, '', 'A', 0),
(640, 16, 60216587, '', 'D', 0),
(641, 17, 28303755, 'A', 'A', 1),
(642, 17, 114339827, '', 'C', 0),
(643, 17, 170782465, '', 'C', 0),
(644, 17, 252775550, '', 'B', 0),
(645, 17, 73726710, '', 'A', 0),
(646, 17, 57609706, '', 'C', 0),
(647, 17, 177060647, '', 'C', 0),
(648, 17, 191826673, '', 'D', 0),
(649, 17, 151648320, '', 'B', 0),
(650, 17, 93589087, '', 'C', 0),
(651, 17, 9477850, '', 'A', 0),
(652, 17, 199317443, '', 'B', 0),
(653, 17, 34926373, '', 'C', 0),
(654, 17, 199543733, '', 'A', 0),
(655, 17, 245943867, '', 'C', 0),
(656, 17, 123227382, '', 'A', 0),
(657, 17, 205617693, '', 'A', 0),
(658, 17, 17027893, '', 'D', 0),
(659, 17, 77905789, '', 'B', 0),
(660, 17, 222786810, '', 'B', 0),
(661, 17, 210502529, '', 'A', 0),
(662, 17, 44926156, '', 'D', 0),
(663, 17, 197091707, '', 'D', 0),
(664, 17, 197342623, '', 'C', 0),
(665, 17, 211358207, '', 'D', 0),
(666, 17, 126948935, '', 'B', 0),
(667, 17, 22827349, '', 'A', 0),
(668, 17, 248520616, '', 'C', 0),
(669, 17, 230725751, '', 'B', 0),
(670, 17, 215870476, '', 'A', 0),
(671, 17, 175537840, '', 'D', 0),
(672, 17, 222824130, '', 'C', 0),
(673, 17, 258418776, '', 'B', 0),
(674, 17, 237848543, '', 'A', 0),
(675, 17, 109714622, '', 'B', 0),
(676, 17, 235557329, '', 'C', 0),
(677, 17, 121444549, '', 'D', 0),
(678, 17, 105536431, '', 'D', 0),
(679, 17, 47936881, '', 'B', 0),
(680, 17, 247380633, '', 'C', 0);

-- --------------------------------------------------------
-- Table structure for table `test_results`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `test_results`;
CREATE TABLE `test_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `test_date` datetime DEFAULT current_timestamp(),
  `start_time` datetime DEFAULT NULL,
  `total_questions` int(11) NOT NULL,
  `correct_answers` int(11) NOT NULL,
  `score_percent` decimal(5,2) NOT NULL,
  `time_spent` int(11) DEFAULT NULL,
  `mode` enum('exam','practice','single','exam_simulator') DEFAULT 'exam',
  `exclude_from_ranking` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_test_date` (`test_date`),
  KEY `idx_user_test_date` (`user_id`,`test_date`),
  KEY `idx_ranking_tests` (`total_questions`,`exclude_from_ranking`),
  KEY `idx_user_mode_date` (`user_id`,`mode`,`test_date`),
  CONSTRAINT `test_results_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `test_results` VALUES 
(1, 1, '2026-06-22 13:07:50', '2026-06-22 12:48:40', 40, 1, '2.50', 1150, 'exam', 0),
(2, 1, '2026-06-24 15:34:35', '2026-06-24 15:34:18', 40, 0, '0.00', 17, 'exam', 0),
(3, 1, '2026-06-24 17:03:25', '2026-06-24 17:03:23', 40, 0, '0.00', 2, 'exam', 0),
(4, 1, '2026-06-24 17:03:59', '2026-06-24 17:03:58', 40, 0, '0.00', 1, 'exam', 0),
(5, 1, '2026-06-24 17:07:46', '2026-06-24 17:07:23', 40, 1, '2.50', 23, 'exam', 0),
(6, 1, '2026-06-24 17:43:57', '2026-06-24 17:43:41', 40, 0, '0.00', 16, 'exam', 0),
(7, 1, '2026-06-24 18:29:35', '2026-06-24 18:28:25', 40, 0, '0.00', 70, 'exam', 0),
(8, 1, '2026-06-24 19:17:03', '2026-06-24 18:34:37', 40, 0, '0.00', 2546, 'exam', 0),
(9, 1, '2026-06-24 20:15:36', '2026-06-24 20:15:32', 40, 0, '0.00', 4, 'exam_simulator', 0),
(10, 1, '2026-06-24 20:16:49', '2026-06-24 20:15:56', 40, 2, '5.00', 53, 'exam', 0),
(11, 1, '2026-07-01 18:54:43', '2026-07-01 18:54:38', 40, 0, '0.00', 5, 'exam', 0),
(12, 1, '2026-07-12 21:42:30', '2026-07-12 21:42:24', 40, 0, '0.00', 6, 'exam', 0),
(13, 1, '2026-07-31 18:13:13', '2026-07-31 18:13:08', 40, 0, '0.00', 5, 'exam', 0),
(14, 1, '2026-07-31 18:20:58', '2026-07-31 18:20:47', 40, 0, '0.00', 11, 'exam', 0),
(15, 1, '2026-07-31 18:25:08', '2026-07-31 18:25:02', 40, 0, '0.00', 6, 'exam', 0),
(16, 1, '2026-07-31 18:31:01', '2026-07-31 18:29:29', 40, 0, '0.00', 92, 'exam', 0),
(17, 1, '2026-07-31 18:33:45', '2026-07-31 18:33:39', 40, 1, '2.50', 6, 'exam', 0);

-- --------------------------------------------------------
-- Table structure for table `unranked_usage`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `unranked_usage`;
CREATE TABLE `unranked_usage` (
  `user_id` int(11) NOT NULL,
  `used_date` date NOT NULL,
  `usage_count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`,`used_date`),
  CONSTRAINT `unranked_usage_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `user_active_tests`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_active_tests`;
CREATE TABLE `user_active_tests` (
  `user_id` int(11) NOT NULL,
  `payload` longtext NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`),
  KEY `idx_updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `user_badges`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_badges`;
CREATE TABLE `user_badges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `badge_id` int(11) NOT NULL,
  `earned_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_badge` (`user_id`,`badge_id`),
  KEY `badge_id` (`badge_id`),
  CONSTRAINT `user_badges_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_badges_ibfk_2` FOREIGN KEY (`badge_id`) REFERENCES `badges` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `user_certificates`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_certificates`;
CREATE TABLE `user_certificates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(160) NOT NULL,
  `organization` varchar(160) NOT NULL,
  `obtained_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `user_certificates_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_certificates` VALUES 
(1, 1, 'wfa', 'ZSEM Tech Platforma Edukacyjna', '2026-07-29', 'Certyfikat ukończenia kursu nr ZSEM-CERT-25E779C09D', '2026-07-29 08:47:19');

-- --------------------------------------------------------
-- Table structure for table `user_course_enrollments`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_course_enrollments`;
CREATE TABLE `user_course_enrollments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `status` enum('active','completed') NOT NULL DEFAULT 'active',
  `progress_percent` int(11) NOT NULL DEFAULT 0,
  `enrolled_at` datetime DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_course` (`user_id`,`course_id`),
  KEY `course_id` (`course_id`),
  CONSTRAINT `user_course_enrollments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_course_enrollments_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_course_enrollments` VALUES 
(2, 1, 4, 'completed', 100, '2026-07-29 08:36:10', '2026-08-06 15:39:25');

-- --------------------------------------------------------
-- Table structure for table `user_course_progress`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_course_progress`;
CREATE TABLE `user_course_progress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `status` enum('started','completed') NOT NULL DEFAULT 'started',
  `quiz_score` int(11) DEFAULT NULL,
  `quiz_attempts` int(11) NOT NULL DEFAULT 0,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_item` (`user_id`,`item_id`),
  KEY `course_id` (`course_id`),
  KEY `item_id` (`item_id`),
  KEY `idx_user_course_progress` (`user_id`,`course_id`),
  CONSTRAINT `user_course_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_course_progress_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_course_progress_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `course_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_course_progress` VALUES 
(1, 1, 4, 5, 'completed', NULL, 0, '2026-07-29 08:37:59'),
(3, 1, 4, 6, 'completed', 100, 3, '2026-07-29 08:47:15'),
(6, 1, 4, 7, 'completed', 100, 1, '2026-08-06 15:39:25');

-- --------------------------------------------------------
-- Table structure for table `user_courses`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_courses`;
CREATE TABLE `user_courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(160) NOT NULL,
  `provider` varchar(160) NOT NULL,
  `completed_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `user_courses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `user_daily_missions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_daily_missions`;
CREATE TABLE `user_daily_missions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `mission_type` varchar(50) NOT NULL,
  `mission_description` text NOT NULL,
  `target_value` int(11) DEFAULT 1,
  `current_value` int(11) DEFAULT 0,
  `xp_reward` int(11) DEFAULT 10,
  `is_completed` tinyint(1) DEFAULT 0,
  `assigned_date` date NOT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_mission_day` (`user_id`,`mission_type`,`assigned_date`),
  KEY `idx_user_date` (`user_id`,`assigned_date`),
  CONSTRAINT `user_daily_missions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_daily_missions` VALUES 
(1, 1, 'score_avg', 'Utrzymaj średnią powyżej 75% w dzisiejszych testach.', 75, 3, 60, 0, '2026-06-22', NULL),
(2, 1, 'daily_quick_repeat', 'Powtórz 8 poprawnych pytań dzisiaj.', 8, 1, 20, 0, '2026-06-22', NULL),
(3, 1, 'review_questions', 'Przejdź ponownie 12 pytania, aby utrwalić wiedzę.', 12, 1, 35, 0, '2026-06-22', NULL),
(4, 1, 'weekly_answer_avalanche', 'Udziel 300 poprawnych odpowiedzi w tym tygodniu.', 300, 4, 220, 0, '2026-06-22', NULL),
(5, 1, 'weekly_accuracy_elite', 'Utrzymaj średnią minimum 95% w tym tygodniu.', 95, 1, 250, 0, '2026-06-22', NULL),
(6, 1, 'weekly_accuracy', 'Utrzymaj średnią minimum 70% w tym tygodniu.', 70, 1, 90, 0, '2026-06-22', NULL),
(7, 1, 'monthly_answer_tsunami', 'Zbierz 1200 poprawnych odpowiedzi w tym miesiącu.', 1200, 4, 450, 0, '2026-06-01', NULL),
(8, 1, 'monthly_champion', 'Zrealizuj 15 testów w tym miesiącu.', 15, 10, 120, 0, '2026-06-01', NULL),
(9, 1, 'monthly_precision_90', 'Utrzymaj średnią minimum 90% w tym miesiącu.', 90, 1, 260, 0, '2026-06-01', NULL),
(10, 1, 'score_avg', 'Utrzymaj średnią powyżej 75% w dzisiejszych testach.', 75, 0, 60, 0, '2026-06-23', NULL),
(11, 1, 'daily_titan', 'Ukończ co najmniej 8 testów dzisiaj.', 8, 0, 120, 0, '2026-06-23', NULL),
(12, 1, 'daily_precision_90', 'Utrzymaj średnią minimum 90% w dzisiejszych testach.', 90, 0, 110, 0, '2026-06-23', NULL),
(13, 1, 'daily_legendary_streak', 'Zdobądź serię 25 poprawnych odpowiedzi z rzędu.', 25, 0, 100, 0, '2026-06-24', NULL),
(14, 1, 'daily_precision_90', 'Utrzymaj średnią minimum 90% w dzisiejszych testach.', 90, 1, 110, 0, '2026-06-24', NULL),
(15, 1, 'daily_quick_repeat', 'Powtórz 8 poprawnych pytań dzisiaj.', 8, 3, 20, 0, '2026-06-24', NULL),
(16, 1, 'tests_taken', 'Ukończ co najmniej 3 dowolne testy dzisiaj.', 3, 1, 50, 0, '2026-07-01', NULL),
(17, 1, 'daily_titan', 'Ukończ co najmniej 8 testów dzisiaj.', 8, 1, 120, 0, '2026-07-01', NULL),
(18, 1, 'correct_answers', 'Udziel 20 poprawnych odpowiedzi.', 20, 0, 30, 0, '2026-07-01', NULL),
(19, 1, 'weekly_mastery', 'Ukończ 5 ćwiczeń w tym tygodniu.', 5, 1, 70, 0, '2026-06-29', NULL),
(20, 1, 'weekly_precision_90', 'Utrzymaj średnią minimum 90% w tym tygodniu.', 90, 0, 170, 0, '2026-06-29', NULL),
(21, 1, 'weekly_precision_80', 'Utrzymaj średnią minimum 80% w tym tygodniu.', 80, 0, 120, 0, '2026-06-29', NULL),
(22, 1, 'monthly_perfect_accuracy', 'Utrzymaj średnią minimum 95% w tym miesiącu.', 95, 0, 400, 0, '2026-07-01', NULL),
(23, 1, 'monthly_precision_90', 'Utrzymaj średnią minimum 90% w tym miesiącu.', 90, 0, 260, 0, '2026-07-01', NULL),
(24, 1, 'monthly_answer_tsunami', 'Zbierz 1200 poprawnych odpowiedzi w tym miesiącu.', 1200, 1, 450, 0, '2026-07-01', NULL),
(25, 1, 'daily_answer_storm', 'Udziel 35 poprawnych odpowiedzi dzisiaj.', 35, 0, 60, 0, '2026-07-02', NULL),
(26, 1, 'daily_perfect_precision', 'Utrzymaj średnią minimum 95% w dzisiejszych testach.', 95, 0, 150, 0, '2026-07-02', NULL),
(27, 1, 'daily_grind', 'Ukończ 5 testów dzisiaj.', 5, 0, 80, 0, '2026-07-02', NULL),
(28, 1, 'daily_legendary_streak', 'Zdobądź serię 25 poprawnych odpowiedzi z rzędu.', 25, 0, 100, 0, '2026-07-03', NULL),
(29, 1, 'score_avg', 'Utrzymaj średnią powyżej 75% w dzisiejszych testach.', 75, 0, 60, 0, '2026-07-03', NULL),
(30, 1, 'daily_no_mistake', 'Zdobądź serię 5 poprawnych odpowiedzi z rzędu.', 5, 0, 30, 0, '2026-07-03', NULL),
(31, 2, 'daily_grind', 'Ukończ 5 testów dzisiaj.', 5, 0, 80, 0, '2026-07-03', NULL),
(32, 2, 'daily_legendary_streak', 'Zdobądź serię 25 poprawnych odpowiedzi z rzędu.', 25, 0, 100, 0, '2026-07-03', NULL),
(33, 2, 'correct_answers', 'Udziel 20 poprawnych odpowiedzi.', 20, 0, 30, 0, '2026-07-03', NULL),
(34, 1, 'daily_titan', 'Ukończ co najmniej 8 testów dzisiaj.', 8, 0, 120, 0, '2026-07-09', NULL),
(35, 1, 'tests_taken', 'Ukończ co najmniej 3 dowolne testy dzisiaj.', 3, 0, 50, 0, '2026-07-09', NULL),
(36, 1, 'daily_deep_repeat', 'Powtórz 25 poprawnych pytań dzisiaj.', 25, 0, 55, 0, '2026-07-09', NULL),
(37, 3, 'daily_titan', 'Ukończ co najmniej 8 testów dzisiaj.', 8, 0, 120, 0, '2026-07-10', NULL),
(38, 3, 'daily_answer_sprint', 'Udziel 10 poprawnych odpowiedzi dzisiaj.', 10, 0, 25, 0, '2026-07-10', NULL),
(39, 3, 'daily_answer_storm', 'Udziel 35 poprawnych odpowiedzi dzisiaj.', 35, 0, 60, 0, '2026-07-10', NULL),
(40, 1, 'daily_perfect_precision', 'Utrzymaj średnią minimum 95% w dzisiejszych testach.', 95, 0, 150, 0, '2026-07-12', NULL),
(41, 1, 'daily_titan', 'Ukończ co najmniej 8 testów dzisiaj.', 8, 1, 120, 0, '2026-07-12', NULL),
(42, 1, 'review_questions', 'Przejdź ponownie 12 pytania, aby utrwalić wiedzę.', 12, 0, 35, 0, '2026-07-12', NULL),
(43, 1, 'weekly_marathon', 'Ukończ 12 ćwiczeń w tym tygodniu.', 12, 1, 140, 0, '2026-07-06', NULL),
(44, 1, 'weekly_answer_avalanche', 'Udziel 300 poprawnych odpowiedzi w tym tygodniu.', 300, 0, 220, 0, '2026-07-06', NULL),
(45, 1, 'weekly_answers', 'Udziel 120 poprawnych odpowiedzi w tym tygodniu.', 120, 0, 100, 0, '2026-07-06', NULL),
(46, 1, 'daily_warmup', 'Ukończ 1 dowolny test dzisiaj.', 1, 0, 20, 0, '2026-07-15', NULL),
(47, 1, 'daily_precision_80', 'Utrzymaj średnią minimum 80% w dzisiejszych testach.', 80, 0, 70, 0, '2026-07-15', NULL),
(48, 1, 'streak_daily', 'Zrób testy 3 dni z rzędu.', 3, 0, 45, 0, '2026-07-15', NULL),
(49, 1, 'score_avg', 'Utrzymaj średnią powyżej 75% w dzisiejszych testach.', 75, 0, 60, 0, '2026-07-19', NULL),
(50, 1, 'streak_daily', 'Zrób testy 3 dni z rzędu.', 3, 0, 45, 0, '2026-07-19', NULL),
(51, 1, 'daily_grind', 'Ukończ 5 testów dzisiaj.', 5, 0, 80, 0, '2026-07-19', NULL),
(52, 1, 'review_questions', 'Przejdź ponownie 12 pytania, aby utrwalić wiedzę.', 12, 0, 35, 0, '2026-07-29', NULL),
(53, 1, 'daily_grind', 'Ukończ 5 testów dzisiaj.', 5, 0, 80, 0, '2026-07-29', NULL),
(54, 1, 'daily_precision_80', 'Utrzymaj średnią minimum 80% w dzisiejszych testach.', 80, 0, 70, 0, '2026-07-29', NULL),
(55, 1, 'correct_answers', 'Udziel 20 poprawnych odpowiedzi.', 20, 0, 30, 0, '2026-07-30', NULL),
(56, 1, 'daily_precision_90', 'Utrzymaj średnią minimum 90% w dzisiejszych testach.', 90, 0, 110, 0, '2026-07-30', NULL),
(57, 1, 'daily_titan', 'Ukończ co najmniej 8 testów dzisiaj.', 8, 0, 120, 0, '2026-07-30', NULL),
(58, 1, 'weekly_precision_90', 'Utrzymaj średnią minimum 90% w tym tygodniu.', 90, 1, 170, 0, '2026-07-27', NULL),
(59, 1, 'weekly_marathon', 'Ukończ 12 ćwiczeń w tym tygodniu.', 12, 5, 140, 0, '2026-07-27', NULL),
(60, 1, 'weekly_answer_sprint', 'Udziel 80 poprawnych odpowiedzi w tym tygodniu.', 80, 1, 75, 0, '2026-07-27', NULL),
(61, 1, 'daily_quick_repeat', 'Powtórz 8 poprawnych pytań dzisiaj.', 8, 1, 20, 0, '2026-07-31', NULL),
(62, 1, 'daily_answer_sprint', 'Udziel 10 poprawnych odpowiedzi dzisiaj.', 10, 1, 25, 0, '2026-07-31', NULL),
(63, 1, 'daily_titan', 'Ukończ co najmniej 8 testów dzisiaj.', 8, 5, 120, 0, '2026-07-31', NULL),
(64, 1, 'daily_grind', 'Ukończ 5 testów dzisiaj.', 5, 0, 80, 0, '2026-08-01', NULL),
(65, 1, 'daily_answer_sprint', 'Udziel 10 poprawnych odpowiedzi dzisiaj.', 10, 0, 25, 0, '2026-08-01', NULL),
(66, 1, 'daily_perfect_precision', 'Utrzymaj średnią minimum 95% w dzisiejszych testach.', 95, 0, 150, 0, '2026-08-01', NULL),
(67, 1, 'monthly_champion', 'Zrealizuj 15 testów w tym miesiącu.', 15, 0, 120, 0, '2026-08-01', NULL),
(68, 1, 'monthly_answer_storm', 'Zbierz 800 poprawnych odpowiedzi w tym miesiącu.', 800, 0, 320, 0, '2026-08-01', NULL),
(69, 1, 'monthly_perfect_accuracy', 'Utrzymaj średnią minimum 95% w tym miesiącu.', 95, 0, 400, 0, '2026-08-01', NULL),
(70, 1, 'daily_no_mistake', 'Zdobądź serię 5 poprawnych odpowiedzi z rzędu.', 5, 0, 30, 0, '2026-08-02', NULL),
(71, 1, 'review_questions', 'Przejdź ponownie 12 pytania, aby utrwalić wiedzę.', 12, 0, 35, 0, '2026-08-02', NULL),
(72, 1, 'daily_grind', 'Ukończ 5 testów dzisiaj.', 5, 0, 80, 0, '2026-08-02', NULL),
(73, 1, 'review_questions', 'Przejdź ponownie 12 pytania, aby utrwalić wiedzę.', 12, 0, 35, 0, '2026-08-03', NULL),
(74, 1, 'streak_daily', 'Zrób testy 3 dni z rzędu.', 3, 0, 45, 0, '2026-08-03', NULL),
(75, 1, 'daily_warmup', 'Ukończ 1 dowolny test dzisiaj.', 1, 0, 20, 0, '2026-08-03', NULL),
(76, 1, 'weekly_test_runner', 'Ukończ 8 ćwiczeń w tym tygodniu.', 8, 0, 100, 0, '2026-08-03', NULL),
(77, 1, 'weekly_marathon', 'Ukończ 12 ćwiczeń w tym tygodniu.', 12, 0, 140, 0, '2026-08-03', NULL),
(78, 1, 'weekly_accuracy', 'Utrzymaj średnią minimum 70% w tym tygodniu.', 70, 0, 90, 0, '2026-08-03', NULL),
(79, 1, 'review_questions', 'Przejdź ponownie 12 pytania, aby utrwalić wiedzę.', 12, 0, 35, 0, '2026-08-04', NULL),
(80, 1, 'correct_answers', 'Udziel 20 poprawnych odpowiedzi.', 20, 0, 30, 0, '2026-08-04', NULL),
(81, 1, 'daily_perfect_chain', 'Zdobądź serię 15 poprawnych odpowiedzi z rzędu.', 15, 0, 70, 0, '2026-08-04', NULL),
(82, 1, 'daily_precision_90', 'Utrzymaj średnią minimum 90% w dzisiejszych testach.', 90, 0, 110, 0, '2026-08-05', NULL),
(83, 1, 'streak_correct', 'Zdobądź serię 10 poprawnych odpowiedzi z rzędu.', 10, 0, 40, 0, '2026-08-05', NULL),
(84, 1, 'correct_answers', 'Udziel 20 poprawnych odpowiedzi.', 20, 0, 30, 0, '2026-08-05', NULL),
(85, 1, 'daily_deep_repeat', 'Powtórz 25 poprawnych pytań dzisiaj.', 25, 0, 55, 0, '2026-08-06', NULL),
(86, 1, 'daily_no_mistake', 'Zdobądź serię 5 poprawnych odpowiedzi z rzędu.', 5, 0, 30, 0, '2026-08-06', NULL),
(87, 1, 'daily_answer_sprint', 'Udziel 10 poprawnych odpowiedzi dzisiaj.', 10, 0, 25, 0, '2026-08-06', NULL),
(88, 1, 'daily_no_mistake', 'Zdobądź serię 5 poprawnych odpowiedzi z rzędu.', 5, 0, 30, 0, '2026-08-16', NULL),
(89, 1, 'review_questions', 'Przejdź ponownie 12 pytania, aby utrwalić wiedzę.', 12, 0, 35, 0, '2026-08-16', NULL),
(90, 1, 'streak_daily', 'Zrób testy 3 dni z rzędu.', 3, 0, 45, 0, '2026-08-16', NULL),
(91, 1, 'weekly_precision_80', 'Utrzymaj średnią minimum 80% w tym tygodniu.', 80, 0, 120, 0, '2026-08-10', NULL),
(92, 1, 'weekly_test_runner', 'Ukończ 8 ćwiczeń w tym tygodniu.', 8, 0, 100, 0, '2026-08-10', NULL),
(93, 1, 'weekly_precision_90', 'Utrzymaj średnią minimum 90% w tym tygodniu.', 90, 0, 170, 0, '2026-08-10', NULL);

-- --------------------------------------------------------
-- Table structure for table `user_education`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_education`;
CREATE TABLE `user_education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `level` enum('podstawowe','średnie','wyższe') NOT NULL,
  `school_name` varchar(160) NOT NULL,
  `field` varchar(160) DEFAULT NULL,
  `start_year` smallint(6) NOT NULL,
  `end_year` smallint(6) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `user_education_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `user_languages`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_languages`;
CREATE TABLE `user_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `language_name` varchar(80) NOT NULL,
  `level` enum('podstawowy','średni','zaawansowany','biegły') NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `user_languages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `user_mfa`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_mfa`;
CREATE TABLE `user_mfa` (
  `user_id` int(11) NOT NULL,
  `secret` varchar(64) NOT NULL,
  `enabled_at` datetime DEFAULT NULL,
  `recovery_codes_hash` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`),
  KEY `idx_enabled` (`enabled_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `user_organizations`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_organizations`;
CREATE TABLE `user_organizations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(160) NOT NULL,
  `role_name` varchar(160) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `user_organizations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `user_passkeys`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_passkeys`;
CREATE TABLE `user_passkeys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `credential_id` varchar(255) NOT NULL,
  `public_key` text NOT NULL,
  `counter` int(11) NOT NULL DEFAULT 0,
  `device_name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `last_used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `credential_id` (`credential_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_passkeys` VALUES 
(2, 1, 'KLxheRAuTAkItdmBQxzQ6g==', '-----BEGIN PUBLIC KEY-----\nMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEVr0hrrJ1J0VRAO5/bogMhe7vrkaE\nG1+CiI5CFdQuPL5OJN0J+quiKt8ChD2jAHB9AfhkkGG+dsWjZFLEiTV24w==\n-----END PUBLIC KEY-----\n', 0, 'Moje urządzenie', '2026-07-03 19:15:48', '2026-07-03 19:16:06');

-- --------------------------------------------------------
-- Table structure for table `user_question_progress`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_question_progress`;
CREATE TABLE `user_question_progress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `times_seen` int(11) DEFAULT 0,
  `times_correct` int(11) DEFAULT 0,
  `last_seen` datetime DEFAULT NULL,
  `is_mastered` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_question` (`user_id`,`question_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_question_id` (`question_id`),
  KEY `idx_mastered` (`is_mastered`),
  KEY `idx_user_mastered_last` (`user_id`,`is_mastered`,`last_seen`),
  KEY `idx_question_mastered` (`question_id`,`is_mastered`),
  CONSTRAINT `user_question_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_question_progress` VALUES 
(1, 1, 121614018, 1, 1, '2026-06-22 12:48:46', 0),
(2, 1, 16659992, 1, 0, '2026-06-22 13:07:37', 0),
(3, 1, 224074393, 1, 0, '2026-06-22 13:07:43', 0),
(4, 1, 144830888, 1, 0, '2026-06-22 13:07:45', 0),
(5, 1, 48073044, 1, 0, '2026-06-24 17:07:25', 0),
(6, 1, 20318573, 1, 1, '2026-06-24 17:07:39', 0),
(7, 1, 103714899, 1, 0, '2026-06-24 17:43:43', 0),
(8, 1, 132835266, 1, 0, '2026-06-24 17:43:45', 0),
(9, 1, 54262822, 1, 0, '2026-06-24 18:28:27', 0),
(10, 1, 28623045, 1, 0, '2026-06-24 18:34:40', 0),
(11, 1, 166844290, 1, 0, '2026-06-24 19:16:42', 0),
(12, 1, 182091331, 1, 1, '2026-06-24 20:16:01', 0),
(13, 1, 258454574, 1, 1, '2026-06-24 20:16:26', 0),
(14, 1, 115273577, 1, 0, '2026-06-24 20:16:29', 0),
(15, 1, 63438007, 1, 0, '2026-06-24 20:16:42', 0),
(16, 1, 207777015, 1, 0, '2026-07-12 21:42:26', 0),
(17, 1, 79289126, 1, 0, '2026-07-31 18:13:11', 0),
(18, 1, 56246144, 1, 0, '2026-07-31 18:20:52', 0),
(19, 1, 4232276, 1, 0, '2026-07-31 18:20:53', 0),
(20, 1, 182125913, 1, 0, '2026-07-31 18:20:56', 0),
(21, 1, 28303755, 1, 1, '2026-07-31 18:33:43', 0);

-- WARNING: Skipped table `user_social_links`: SQLSTATE[42S02]: Base table or view not found: 1932 Table 'rafifafi_egzamin.user_social_links' doesn't exist in engine

-- --------------------------------------------------------
-- Table structure for table `user_volunteering`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_volunteering`;
CREATE TABLE `user_volunteering` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `organization` varchar(160) NOT NULL,
  `role_name` varchar(160) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `user_volunteering_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table structure for table `users`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('user','teacher','admin','dyrektor','wujek_luki') DEFAULT 'user',
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `class` varchar(20) DEFAULT NULL,
  `class_year` tinyint(3) unsigned DEFAULT NULL,
  `class_suffix` varchar(2) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `avatar_path` varchar(255) DEFAULT NULL,
  `avatar_changed_at` datetime DEFAULT NULL,
  `xp` int(11) DEFAULT 4100,
  `profile_public` tinyint(1) DEFAULT 1,
  `stats_public` tinyint(1) DEFAULT 1,
  `allow_profile_comments` tinyint(1) DEFAULT 1,
  `allow_friend_requests` tinyint(1) DEFAULT 1,
  `searchable` tinyint(1) DEFAULT 1,
  `is_verified` tinyint(1) DEFAULT 0,
  `verified_at` datetime DEFAULT NULL,
  `verified_by_admin_id` int(11) DEFAULT NULL,
  `ranking_visible` tinyint(1) NOT NULL DEFAULT 0,
  `verification_token` varchar(255) DEFAULT NULL,
  `is_banned` tinyint(1) DEFAULT 0,
  `ban_expires_at` datetime DEFAULT NULL,
  `trust_status` varchar(30) NOT NULL DEFAULT 'trusted',
  `risk_flags` text DEFAULT NULL,
  `registration_ip` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `last_login` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `session_version` int(11) NOT NULL DEFAULT 1,
  `show_online_status` tinyint(1) DEFAULT 1,
  `show_recent_activity` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_username` (`username`),
  KEY `idx_email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_verified` (`is_verified`),
  KEY `idx_banned` (`is_banned`),
  KEY `idx_ban_expiry` (`is_banned`,`ban_expires_at`),
  KEY `idx_trust_status` (`trust_status`),
  KEY `idx_registration_ip` (`registration_ip`),
  KEY `idx_role_xp_activity` (`role`,`xp`,`last_activity`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES 
(1, 'test', 'damian.2008pod@gmail.com', '$argon2id$v=19$m=65536,t=4,p=1$RTVYdmtJanpZZTlCaWRHSg$XNI+MwsWUYomdmdsA+ccFCTkV5rldjoULgdVBR4jt4A', 'dyrektor', 'Damian', 'Podgorski', NULL, NULL, '', NULL, NULL, NULL, 0, 1, 1, 1, 1, 1, 0, NULL, NULL, 0, '44d12e65e1025ca4cf0ccd4f839a3098b462febfc5415885cc0328693388e5bc', 0, NULL, 'trusted', NULL, '::1', '2026-06-22 10:46:02', '2026-08-16 21:30:17', '::1', '2026-08-16 21:40:58', 1, 1, 1),
(2, 'kappi', 'streax450@gmail.com', '$2y$10$Z8jB05xao1kq7oRxuXD87e/l.tfHYzEpJMLvKmZzGSadvLHEx4cly', 'user', 'kappi', 'kappi', NULL, NULL, '', NULL, NULL, NULL, 4100, 1, 1, 1, 1, 1, 0, NULL, NULL, 0, '431b7b42d0f391b27ad6e57d320d54089dfab4049b82d32d1d1f5d066c0f657b', 0, NULL, 'trusted', NULL, '::1', '2026-07-03 19:12:52', '2026-07-03 19:14:37', '::1', '2026-07-03 19:14:37', 1, 1, 1),
(3, 'test47', 'test@wp.pl', '$2y$10$32haspYspeEIYX5b3OGx5uFxEaLT/2V9InmJMDgcJKvoEFP0t4kZi', 'user', 'test', 'test', NULL, NULL, '', NULL, NULL, NULL, 4100, 1, 1, 1, 1, 1, 0, NULL, NULL, 0, 'd5c5fec4040cdc813ae57c3c9a5dedf5f0d67e637b8913b3f3e1cede8333c469', 0, NULL, 'trusted', NULL, '192.168.1.135', '2026-07-10 21:34:32', '2026-07-10 21:34:32', '192.168.1.135', '2026-07-10 21:36:40', 1, 1, 1);

-- --------------------------------------------------------
-- Table structure for table `xp_events`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `xp_events`;
CREATE TABLE `xp_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `source` varchar(50) NOT NULL,
  `source_id` int(11) DEFAULT NULL,
  `amount` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_created` (`user_id`,`created_at`),
  KEY `idx_source` (`source`,`source_id`),
  CONSTRAINT `xp_events_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `xp_events` VALUES 
(1, 1, 'test', 1, -400, 'Korekta XP za wynik testu rankingowego', '2026-06-22 13:07:50'),
(2, 1, 'test', 2, -400, 'Korekta XP za wynik testu rankingowego', '2026-06-24 15:34:35'),
(3, 1, 'test', 3, -400, 'Korekta XP za wynik testu rankingowego', '2026-06-24 17:03:25'),
(4, 1, 'test', 4, -400, 'Korekta XP za wynik testu rankingowego', '2026-06-24 17:03:59'),
(5, 1, 'test', 5, -400, 'Korekta XP za wynik testu rankingowego', '2026-06-24 17:07:46'),
(6, 1, 'test', 6, -400, 'Korekta XP za wynik testu rankingowego', '2026-06-24 17:43:57'),
(7, 1, 'test', 7, -400, 'Korekta XP za wynik testu rankingowego', '2026-06-24 18:29:35'),
(8, 1, 'test', 8, -400, 'Korekta XP za wynik testu rankingowego', '2026-06-24 19:17:03'),
(9, 1, 'test', 9, -400, 'Korekta XP za wynik testu rankingowego', '2026-06-24 20:15:36'),
(10, 1, 'test', 10, -360, 'Korekta XP za wynik testu rankingowego', '2026-06-24 20:16:49'),
(11, 1, 'test', 11, -400, 'Korekta XP za wynik testu rankingowego', '2026-07-01 18:54:43'),
(12, 1, 'test', 12, -400, 'Korekta XP za wynik testu rankingowego', '2026-07-12 21:42:30'),
(13, 1, 'test', 13, -400, 'Korekta XP za wynik testu rankingowego', '2026-07-31 18:13:13'),
(14, 1, 'test', 14, -400, 'Korekta XP za wynik testu rankingowego', '2026-07-31 18:20:58'),
(15, 1, 'test', 15, -400, 'Korekta XP za wynik testu rankingowego', '2026-07-31 18:25:08'),
(16, 1, 'test', 16, -400, 'Korekta XP za wynik testu rankingowego', '2026-07-31 18:31:01'),
(17, 1, 'test', 17, -400, 'Korekta XP za wynik testu rankingowego', '2026-07-31 18:33:45');

SET FOREIGN_KEY_CHECKS = 1;
-- Dump completed on 2026-08-16 19:43:48 UTC
